# Merged into README

This content now lives in [README.md](./README.md) — see "The five approaches"
for the full per-approach breakdown (what code lives where, source vs compiled).
