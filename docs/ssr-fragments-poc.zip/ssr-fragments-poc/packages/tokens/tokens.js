// Design tokens shipped fleet-wide. Exported as JS so fragment components can
// inline them into SSR output (self-contained markup, no external stylesheet
// request) AND as tokens.css for app-level theming. Same values, two shapes.
export const tokens = {
  color: {
    surface: "#ffffff",
    surfaceMuted: "#f5f6f8",
    border: "#e4e7ec",
    text: "#1a1d23",
    textMuted: "#667085",
    accent: "#5b5bd6",
    accentSoft: "#ececfb",
  },
  radius: { md: "10px", pill: "999px" },
  space: { xs: "4px", sm: "8px", md: "12px", lg: "16px" },
  font: {
    family:
      "system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
  },
  shadow: { card: "0 1px 2px rgba(16,24,40,0.06), 0 1px 3px rgba(16,24,40,0.10)" },
};
