# SSR Fragments POC

A monorepo with two apps — **marketplace** (owns the tiles) and **home**
(embeds them) — demonstrating **five ways one app can deliver a UI piece to
another**, each live on a real tile. It answers: how does home show a component
owned by marketplace, and what does each option cost in payload, interactivity
and authoring?

## Install & run

```bash
npm install
npm run dev
#   home        -> http://localhost:3000
#   marketplace -> http://localhost:3001
```

Production:

```bash
npm install
npm run build
npm run preview
```

One install, one command. `dev`/`build` compile the two island packages
(Stencil, Preact) before starting — there is no separate build-in-order step to
run yourself. Open home (`:3000`) to see the embedded fragments; open
marketplace (`:3001`) to see the same tiles used natively.

## What it demonstrates

Marketplace apps are developed by independent pods on their own release cadence,
but share UI. This POC embeds marketplace's tiles inside home without home
importing marketplace's code: marketplace's server produces fragment HTML;
home's server proxies `/fragments/marketplace/*` to marketplace (so the browser
stays same-origin) and, for interactive tiles, the browser loads a small
definition bundle once to bring the markup to life.

Four tiles cover the five approaches: **Agent** (SSR fragment, and the same tile
made interactive by hydration), **Dataset** (hand-rolled web component),
**Skill** (Stencil web component), **Tool** (Preact island).

## The five approaches

| Approach | Example tile | Lives in (authored) | Bundle | Consumer runtime | Interactive |
|---|---|---|---|---|---|
| SSR fragment (static) | Agent (static) | `client/src/fragments/` (+ `components/AgentTile.tsx`) | — | none | no — links only |
| Vanilla web component | Dataset | `client/src/fragments/DatasetTile.element.ts` | **4 KB** | own, no framework | yes — narrow |
| Preact island | **Tool** | `packages/react-fragments/` | **22 KB** | own Preact | yes — narrow |
| Stencil web component | Skill | `packages/fragments/` | **24 KB** | own, no framework | yes — narrow |
| React island (heavy) | Agent (hydrate) | `client/src/fragments/entry.client.tsx` | **146 KB** | own React | yes — narrow |
| Module Federation | — *(not built)* | — | — | shared React singleton | yes — wide |

Bundle = bytes served at `/fragment-client/*.js`. **Every source path above is
under `marketplace/`**, and each approach's server half is uniformly
`marketplace/server/approaches/<name>.js`. Note the split that makes them hard to
find otherwise: Agent and Dataset are authored in the **app** (`client/src`),
while Skill and Tool are their **own compiled packages** (`packages/fragments`
Stencil, `packages/react-fragments` Preact).

Every *built* interactive tile — Dataset, Tool, Skill and Agent-hydrate — bundles
its **own** runtime and shares nothing with the host, so none carries cross-app
dependency discipline. The one option that does — Module Federation, a shared
React singleton negotiated across apps — is **not built here** (see below).

**Pick by:** static / read-mostly → SSR fragment. Self-contained interactive
widget, narrow contract → a web component (vanilla if trivial, Stencil if you
want declarative authoring + batteries) or a Preact/React island (stay in React,
keep your Vite build). Deep host integration, wide contract (shares
routing/state/React, e.g. an assistant panel) → Module Federation (not built here).

### What makes federation *federation*

The distinguishing axis isn't "loaded at runtime" — it's **runtime shared-
dependency negotiation**: independently deployed units resolving to *one* shared
instance of a library (the host provides React, or several remotes dedupe to a
single React copy, declared like `shared: { react: { singleton: true } }`). That
cross-fleet singleton management is federation's defining feature and its
defining cost. If a unit instead **bundles its own runtime** — or links its own
copy from a URL — it's an island or a plain module, not federation, *even when
it's loaded at runtime*.

People sometimes use "Module Federation" loosely for any runtime remote loading;
here we reserve **federation** for the shared-singleton case. By that definition
**none of the tiles in this POC are federation** — every interactive one bundles
its own runtime, on purpose, for simplicity. Federation is the wide-contract
option the ADR deferred; it's the natural home only for a surface that must share
the host's React tree and state (e.g. the assistant panel), and it's what the
146 KB Agent-hydrate island would become if you made it share the host's React
instead of shipping its own.

### Reading key: two boundaries

**Server vs client.** The *server* (marketplace's express) always produces the
fragment HTML and serves the definition bundle. The *client* (home's browser)
embeds that HTML and, for interactive tiers, loads the definition once to
hydrate. Home's server only proxies and serves its own SPA.

**Source vs compiled.** Two different things get "loaded" on the server — the
**SSR renderer** (turns data into fragment HTML) and the **client bundle** (what
the consumer loads to become interactive). Each is either *app source read
through Vite / esbuild-compiled on demand*, or a *precompiled module built ahead
of time*. This is the axis that really separates the approaches:

| Approach | SSR renderer the server loads | Client bundle origin | Built by |
|---|---|---|---|
| Agent (static + hydrate) | app SSR module (`entry.server.tsx`) — dev: Vite `ssrLoadModule` of **source**; prod: the app's built SSR bundle | esbuild-compiled **on demand from app source** (`entry.client.tsx`) | app Vite / esbuild |
| Dataset | app SSR module (a string builder using app data) | esbuild-compiled **on demand from app source** (`DatasetTile.element.ts`) | app Vite / esbuild |
| Skill | app SSR module → delegates to a **precompiled Stencil hydrate** module | esbuild-bundled from **Stencil's precompiled** `dist-custom-elements` | Stencil compiler |
| Tool | a **precompiled Preact SSR** module, imported directly in the middleware | **prebuilt IIFE** from the island's own Vite build (served as-is) | the island's Vite |

So Agent and Dataset render from the app's own code (live source in dev), and
their client bundles are compiled on the fly by the server. Skill and Tool are
authored in separate, ahead-of-time-compiled packages, and the server loads
those *compiled* artifacts.

### 1. SSR fragment (static) — Agent, static

Ship HTML, run nothing on the consumer.

- **Authored (app source):** `client/src/components/AgentTile.tsx` (React),
  `fragments/Agent.tsx`, and the SSR registry `fragments/entry.server.tsx`.
- **Server SSR:** `approaches/agent.js` → `fragmentModule().renderFragment("agent")`.
  Dev loads `ssrLoadModule("/src/fragments/entry.server.tsx")` (live source, HMR);
  prod loads the built `dist/fragments/entry.server.js`. React `renderToString`
  emits self-contained HTML (inline styles; inline `onclick` so the Test buttons
  need no React).
- **Client:** nothing — the consumer injects HTML; links and inline handlers work
  with zero JS.
- **When:** previews, announcements, nav content — read-mostly surfaces.

### 2. React island (heavy) — Agent, hydrate

The same Agent tile, made interactive by shipping its own React. (Despite the
old "federated" shorthand, this is an island, not federation — it bundles React
rather than sharing the host's; see "What makes federation federation" above.)

- **Authored:** `client/src/fragments/entry.client.tsx`
  (`hydrateAgent()` → `createRoot(el).render(<AgentFragment/>)`).
- **Server:** `approaches/agent.js` esbuild-bundles `entry.client.tsx` **from app
  source on demand** into a 146 KB IIFE (React included) at `/fragment-client/agent.js`.
- **Client:** the fragment's "Hydrate" button loads it and mounts a live React
  tile over the static markup. React is bundled *privately* here; true federation
  would *share* one React singleton with the host — the wide-contract, standing-
  discipline option.
- **Runtime:** React, only once hydrated. **Cost:** 146 KB + (if the host is React)
  two Reacts on the page — which is exactly the duplication real federation avoids
  by sharing one React.
- **When:** rarely as-is (the Preact island does the same job at 22 KB). Its value
  is as the stepping stone to federation: if a surface genuinely must share the
  host's React tree/state/routing, you'd switch this from bundling React to
  sharing the host's — that switch is what makes it federation.

### 3. Vanilla web component — Dataset

Hand-written custom element. Smallest interactive option.

- **Authored (app source):** `client/src/fragments/DatasetTile.element.ts` (plain
  `HTMLElement`). Data in `client/src/capabilities/datasets.ts`.
- **Server SSR:** `approaches/dataset.js` → `renderFragment("dataset")`, a **string
  builder** in `entry.server.tsx` emitting `<dataset-tile data-…>` with a light-DOM
  fallback. Uses app data, so it loads through the app SSR module.
- **Client:** the server esbuild-bundles `DatasetTile.element.ts` **from source on
  demand** into a 4 KB IIFE at `/fragment-client/dataset-tile.js`. Home loads it
  once; every `<dataset-tile>` upgrades via `connectedCallback`. Rows API at
  `/api/datasets/:id/rows`.
- **Runtime:** none. **When:** a simple widget where a few DOM calls are fine and
  you want the smallest payload.

### 4. Stencil web component — Skill

Declarative authoring, compiled to a standards element.

- **Authored (separate package):** `packages/fragments/src/components/skill-tile/`
  (`skill-tile.tsx` + `.css`, Stencil TSX + scoped CSS). Data in the app's
  `client/src/capabilities/skills.ts`.
- **Built ahead of time by Stencil** (`stencil build`) into `dist/components`
  (custom elements) and `hydrate/` (a Node `renderToString`).
- **Server SSR:** `approaches/skill.js` → `renderFragment("skill")`, whose renderer
  imports the **precompiled** Stencil hydrate (`@poc/marketplace-fragments/hydrate`)
  and produces **real server-rendered component markup** (scoped `sc-skill-tile`
  classes, hydration markers).
- **Client:** the server esbuild-bundles the **precompiled** `dist-custom-elements`
  into a 24 KB IIFE (Stencil runtime included) at `/fragment-client/skill-tile.js`.
  Home loads it once; Stencil hydrates the SSR markup in place. Endorsements API at
  `/api/skills/:id/endorsements`.
- **Runtime:** Stencil's small runtime. **Cost:** a second build system in the repo.
  **When:** a growing cross-team element library where declarative authoring +
  SSR/hydrate + typed framework wrappers earn the extra compiler.

### 5. Preact island — Tool

Plain React authoring, shipped as Preact, built by Vite (no new compiler).

- **Authored (separate package):** `packages/react-fragments/src/fragments/` —
  `ToolTile.tsx` (plain React, `useState` only, no Context/singletons),
  `tool-tile.element.ts` (custom-element wrapper), `server.tsx`
  (`preact-render-to-string`). Data in the app's `client/src/capabilities/tools.ts`.
- **Built ahead of time by the package's own Vite**, with `react` aliased to
  `preact/compat`: `dist/client/tool-tile.{iife,es}.js` (element) + `dist/ssr`.
- **Server SSR:** `approaches/tool.js` imports the **precompiled** Preact SSR
  (`@poc/react-fragments/ssr`) **directly** and wraps its output in `<tool-tile>`.
  Only the tool *data* comes from the app (`fragmentModule().getTool`) — unlike
  Skill, the render doesn't go through `entry.server.tsx`.
- **Client:** the server serves the **prebuilt** 22 KB IIFE as-is (no esbuild) at
  `/fragment-client/tool-tile.js`. Home loads it once; the wrapper hydrates the SSR
  markup with Preact. Run API at `/api/tools/:id/run`.
- **Runtime:** Preact (own copy). **When:** you want to reuse React skills and your
  existing Vite build, stay island-sized, and avoid a second compiler.

## Server layout — one middleware per approach

```
marketplace/server/
  index.js                 thin: create runtime, mount the four routers, serve SPA
  runtime.js               shared plumbing:
                             - dev Vite server / prod module loader (fragmentModule)
                             - esbuild-IIFE helper (iifeBundle)
                             - fragment-route wrapper (status + cache + fallback)
                             - CORS / json helpers, PUBLIC_ORIGIN, attr/str
  approaches/
    agent.js               /fragments/agent   + /fragment-client/agent.js
    dataset.js             /fragments/dataset  + /fragment-client/dataset-tile.js + rows API
    skill.js               /fragments/skill    + /fragment-client/skill-tile.js  + endorsements API
    tool.js                /fragments/tool     + /fragment-client/tool-tile.js   + run API
```

Read one `approaches/*.js` to see a tier's entire server footprint (~25–40 lines).
`home/server/index.js` is separate and tiny: serves the home SPA and proxies
`/fragments/marketplace/*` to marketplace; definition bundles load cross-origin
from marketplace (CORS-open, internal-only).

## Repo layout

```
packages/tokens/                fleet-wide design tokens (CSS vars + JS)
marketplace/                    OWNER app
  .env                          APP_TITLE=Marketplace
  client/src/
    env.ts                      reads APP_TITLE from window.env | process.env
    components/AgentTile.tsx     React tile + Test Server/Host/Client buttons
    capabilities/               agents.ts, datasets.ts, skills.ts, tools.ts (data)
    pages/                       AgentList / DatasetList / SkillList / ToolList
    fragments/
      Agent.tsx                  React fragment (renders AgentTile)
      entry.server.tsx           SSR registry: agent (React), dataset (string), skill (Stencil)
      entry.client.tsx           hydrateAgent(): mount live React on demand
      DatasetTile.element.ts     vanilla web component
  server/                       split per approach (see Server layout)
  packages/fragments/           Stencil package (own compiler) — SkillTile
  packages/react-fragments/     Preact island (Vite) — ToolTile
home/                           CONSUMER app
  .env                          APP_TITLE=Home, MARKETPLACE_ORIGIN=...
  client/src/
    components/Fragment.tsx      ~40-line helper: fetch + inject + fallback
    capabilities/               favorites (agents), datasetFavorites, skillFavorites, toolFavorites
    pages/Home.tsx
  server/index.js               SPA + /fragments/marketplace/* proxy
```

## Extra experiments in the code

Two things layered on the tiles, worth knowing:

- **Env flow (`APP_TITLE`).** One `env.ts` reads a value lazily from `window.env`
  in the browser (injected by a small Vite plugin from the app's `.env`) or
  `process.env` on the server (via `dotenv`). Each app has its own `.env`
  (`Marketplace` / `Home`). It shows that a server-rendered fragment carries the
  **owner's** env, while each SPA reads its **own**.

- **Agent Test buttons + on-demand hydration.** On `AgentTile`: **Test Server**
  (inline `onclick`, title baked at SSR = owner env), **Test Host** (inline, reads
  `window.env` at click = host env), **Test Client** (React `onClick`, inert in a
  static embed). The fragment's **Hydrate** button mounts a live React tile over
  the static markup — after which the tile reads the **host's** env, so the value
  flips owner→host. It's the concrete demonstration of why interactivity in an
  embed reintroduces coupling: you're now running the owner's code in the host.

## Build gotchas found along the way

Vite 6's `vite build --ssr` needs the entry passed explicitly on the CLI; the
dev express server must pass `configFile` to Vite's `createServer` (else it
ignores the app-root config and silently drops plugins); and `ssr.noExternal`
must be scoped to the SSR build only, or dev `ssrLoadModule` chokes on React's
CommonJS.
