// STALE DUPLICATE — ignore and delete. Created by the editor/sync layer when
// vite.config.ts was overwritten. Vite only loads vite.config.ts. Kept inert
// because the sandbox filesystem would not allow deleting it.
export {};
