// Env access, resolved ON DEMAND from whichever source exists at runtime.
// No values are defined here — this only reads them.
//
//   browser (SPA):  window.env      <- injected by the window-env vite plugin
//   node   (SSR) :  process.env     <- loaded from .env by dotenv in the server
//
// This split is the whole point of the experiment: a server-rendered fragment
// resolves APP_TITLE from the OWNING app's process.env, while each SPA resolves
// it from its own window.env. Same env.ts, different source per runtime.

declare global {
  interface Window {
    env?: Record<string, string | undefined>;
  }
}

function readEnv(key: string): string | undefined {
  // bracket access (not process.env.APP_TITLE) so bundlers don't inline it
  if (typeof window !== "undefined" && window.env) return window.env[key];
  if (typeof process !== "undefined" && process.env) return process.env[key];
  return undefined;
}

export function getAppTitle(): string {
  return readEnv("APP_TITLE") ?? "unknown";
}
