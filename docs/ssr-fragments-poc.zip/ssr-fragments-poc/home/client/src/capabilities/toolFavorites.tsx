import { useEffect } from "react";
import { Fragment } from "../components/Fragment";
import { tokens } from "@poc/tokens";

// Favorite tools — same cross-app pattern. The tiles are Preact islands,
// server-rendered by marketplace and hydrated after the definition loads once.
const TOOL_FAV_IDS = ["1", "2", "3"];

let definitionRequested = false;
function loadToolDefinitionOnce() {
  if (definitionRequested) return;
  definitionRequested = true;
  const origin =
    (window.env && window.env.MARKETPLACE_ORIGIN) || "http://localhost:3001";
  const s = document.createElement("script");
  s.src = `${origin}/fragment-client/tool-tile.js`;
  document.head.appendChild(s);
}

export function FavoriteTools() {
  useEffect(loadToolDefinitionOnce, []);
  return (
    <section style={{ marginTop: tokens.space.lg }}>
      <h2 style={{ fontSize: 16 }}>Favorite tools</h2>
      <p style={{ color: tokens.color.textMuted, marginTop: 0, fontSize: 13 }}>
        Embedded from marketplace as <strong>React islands (Preact)</strong>,
        server-rendered then hydrated. Load the ~10 KB definition once → expand
        params, run the tool.
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {TOOL_FAV_IDS.map((id) => (
          <Fragment
            key={id}
            src={`/fragments/marketplace/tool?id=${encodeURIComponent(id)}`}
            fallback={
              <div
                style={{
                  border: `1px dashed ${tokens.color.border}`,
                  borderRadius: tokens.radius.md,
                  padding: tokens.space.lg,
                  color: tokens.color.textMuted,
                  fontSize: 13,
                }}
              >
                Preview unavailable
              </div>
            }
          />
        ))}
      </div>
    </section>
  );
}
