import { Fragment } from "../components/Fragment";
import { tokens } from "@poc/tokens";

// Capability: the "favorite agents" feature. Domain-aware — it knows which
// agents are favorites and where marketplace's fragment endpoint is. The tiles
// it shows are NOT imported from marketplace; they're HTML embeds fetched from
// marketplace's SSR fragment endpoint (proxied same-origin through home's
// server, so the browser call stays same-origin and marketplace stays private).
const FAVORITE_AGENT_IDS = ["1", "2", "3"];
const fragmentUrl = (id: string) =>
  `/fragments/marketplace/agent?id=${encodeURIComponent(id)}`;

export function FavoriteAgents() {
  return (
    <section>
      <h2 style={{ fontSize: 16 }}>Favorite agents</h2>
      <p style={{ color: tokens.color.textMuted, marginTop: 0, fontSize: 13 }}>
        Embedded from marketplace via SSR fragments (not a shared React import).
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {FAVORITE_AGENT_IDS.map((id) => (
          <Fragment
            key={id}
            src={fragmentUrl(id)}
            fallback={
              <div
                style={{
                  border: `1px dashed ${tokens.color.border}`,
                  borderRadius: tokens.radius.md,
                  padding: tokens.space.lg,
                  color: tokens.color.textMuted,
                  fontSize: 13,
                }}
              >
                Preview unavailable
              </div>
            }
          />
        ))}
      </div>
    </section>
  );
}
