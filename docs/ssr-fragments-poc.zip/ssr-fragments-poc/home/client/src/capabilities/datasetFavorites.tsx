import { useEffect } from "react";
import { Fragment } from "../components/Fragment";
import { tokens } from "@poc/tokens";

// Capability: favorite datasets. Same fragment-embed mechanism as agents, but
// the tiles are web components. The ONLY extra step vs a static embed is loading
// marketplace's <dataset-tile> definition ONCE — after that, every dataset
// fragment (these three and any injected later) upgrades itself automatically.
// No per-tile hydrate button, no React, no events between tile and host.
const DATASET_FAV_IDS = ["1", "2", "3"];

let definitionRequested = false;
function loadDatasetDefinitionOnce() {
  if (definitionRequested) return;
  definitionRequested = true;
  const origin =
    (window.env && window.env.MARKETPLACE_ORIGIN) || "http://localhost:3001";
  const s = document.createElement("script");
  s.src = `${origin}/fragment-client/dataset-tile.js`;
  document.head.appendChild(s);
}

export function FavoriteDatasets() {
  useEffect(loadDatasetDefinitionOnce, []);
  return (
    <section style={{ marginTop: tokens.space.lg }}>
      <h2 style={{ fontSize: 16 }}>Favorite datasets</h2>
      <p style={{ color: tokens.color.textMuted, marginTop: 0, fontSize: 13 }}>
        Embedded from marketplace as <strong>web components</strong>. Load the
        definition once → the tiles become interactive (expand columns, preview
        rows) with no React and no hydrate step.
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {DATASET_FAV_IDS.map((id) => (
          <Fragment
            key={id}
            src={`/fragments/marketplace/dataset?id=${encodeURIComponent(id)}`}
            fallback={
              <div
                style={{
                  border: `1px dashed ${tokens.color.border}`,
                  borderRadius: tokens.radius.md,
                  padding: tokens.space.lg,
                  color: tokens.color.textMuted,
                  fontSize: 13,
                }}
              >
                Preview unavailable
              </div>
            }
          />
        ))}
      </div>
    </section>
  );
}
