import { useEffect } from "react";
import { Fragment } from "../components/Fragment";
import { tokens } from "@poc/tokens";

// Favorite skills — same cross-app pattern as datasets, but the tiles are
// SSR'd by Stencil (server-rendered markup, not a fallback) and the definition
// bundle is the Stencil element. Load it once → every <skill-tile> hydrates.
const SKILL_FAV_IDS = ["1", "2", "3"];

let definitionRequested = false;
function loadSkillDefinitionOnce() {
  if (definitionRequested) return;
  definitionRequested = true;
  const origin =
    (window.env && window.env.MARKETPLACE_ORIGIN) || "http://localhost:3001";
  const s = document.createElement("script");
  s.src = `${origin}/fragment-client/skill-tile.js`;
  document.head.appendChild(s);
}

export function FavoriteSkills() {
  useEffect(loadSkillDefinitionOnce, []);
  return (
    <section style={{ marginTop: tokens.space.lg }}>
      <h2 style={{ fontSize: 16 }}>Favorite skills</h2>
      <p style={{ color: tokens.color.textMuted, marginTop: 0, fontSize: 13 }}>
        Embedded from marketplace as <strong>Stencil</strong> web components,{" "}
        <strong>server-rendered</strong> (real markup, not a fallback). Load the
        definition once → they hydrate (expand criteria, load endorsements).
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {SKILL_FAV_IDS.map((id) => (
          <Fragment
            key={id}
            src={`/fragments/marketplace/skill?id=${encodeURIComponent(id)}`}
            fallback={
              <div
                style={{
                  border: `1px dashed ${tokens.color.border}`,
                  borderRadius: tokens.radius.md,
                  padding: tokens.space.lg,
                  color: tokens.color.textMuted,
                  fontSize: 13,
                }}
              >
                Preview unavailable
              </div>
            }
          />
        ))}
      </div>
    </section>
  );
}
