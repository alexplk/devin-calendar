import { FavoriteAgents } from "../capabilities/favorites";
import { FavoriteDatasets } from "../capabilities/datasetFavorites";
import { FavoriteSkills } from "../capabilities/skillFavorites";
import { FavoriteTools } from "../capabilities/toolFavorites";
import { getAppTitle } from "../env";
import { tokens } from "@poc/tokens";

// Page: composed from capabilities, otherwise dumb.
export function Home() {
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: tokens.space.lg }}>
      <h1 style={{ fontSize: 22 }}>Home</h1>
      <p style={{ color: tokens.color.textMuted, marginTop: 0 }}>
        This SPA reads <code>window.env.APP_TITLE</code> ={" "}
        <strong>{getAppTitle()}</strong>. The embedded tiles below are SSR'd by
        marketplace, so their Test button alerts <strong>Marketplace</strong>.
      </p>
      <FavoriteAgents />
      <FavoriteDatasets />
      <FavoriteSkills />
      <FavoriteTools />
    </main>
  );
}
