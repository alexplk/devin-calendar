import { useEffect, useRef, useState } from "react";

// Dumb, domain-unaware consumer helper (the ~40-line piece from the ADR).
// Fetches a fragment's HTML from a same-origin URL and injects it. On any
// non-200 / timeout it renders the fallback. Sources are internal-only, so we
// trust the markup (CSP would back this in prod) rather than sanitize.
export function Fragment({
  src,
  fallback = null,
  timeoutMs = 4000,
}: {
  src: string;
  fallback?: React.ReactNode;
  timeoutMs?: number;
}) {
  const [html, setHtml] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let alive = true;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    fetch(src, { signal: ctrl.signal })
      .then((r) => (r.ok ? r.text() : Promise.reject(new Error(String(r.status)))))
      .then((t) => alive && setHtml(t))
      .catch(() => alive && setFailed(true))
      .finally(() => clearTimeout(timer));
    return () => {
      alive = false;
      ctrl.abort();
      clearTimeout(timer);
    };
  }, [src, timeoutMs]);

  if (failed) return <>{fallback}</>;
  if (html == null)
    return <div style={{ minHeight: 96, opacity: 0.4 }} aria-busy="true" />;
  return <div ref={ref} dangerouslySetInnerHTML={{ __html: html }} />;
}
