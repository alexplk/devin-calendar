import { defineConfig, loadEnv, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";

const appRoot = fileURLToPath(new URL(".", import.meta.url)); // home/

// Inject whitelisted env onto window.env for the browser (see marketplace config).
function windowEnv(mode: string): Plugin {
  const env = loadEnv(mode, appRoot, "");
  const exposed = {
    APP_TITLE: env.APP_TITLE ?? "",
    // needed by the browser to load marketplace's web-component definition
    MARKETPLACE_ORIGIN: env.MARKETPLACE_ORIGIN ?? "",
  };
  return {
    name: "window-env",
    transformIndexHtml(html) {
      return html.replace(
        "</head>",
        `  <script>window.env=${JSON.stringify(exposed)}</script>\n  </head>`,
      );
    },
  };
}

// Home is a plain consumer: it produces no fragments of its own, so it only has
// a client build. It renders marketplace fragments as HTML embeds at runtime.
export default defineConfig(({ mode }) => ({
  root: fileURLToPath(new URL("./client", import.meta.url)),
  envDir: appRoot,
  plugins: [react(), windowEnv(mode)],
  build: { outDir: "../dist/client", emptyOutDir: true },
  server: { port: 3000, hmr: { port: 24679 } },
}));
