import "dotenv/config"; // loads ./.env into process.env (server-side env source)
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Home express server. Serves the Home SPA and proxies marketplace's fragment
// endpoint so the browser fetches same-origin (/fragments/marketplace/...) and
// marketplace never has to be publicly reachable or CORS-open. This is the
// "server-to-server through the host's proxy" auth path from the ADR.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === "production";
const PORT = process.env.PORT || 3000;
const MARKETPLACE_ORIGIN =
  process.env.MARKETPLACE_ORIGIN || "http://localhost:3001";

const app = express();

// Proxy: /fragments/marketplace/agent?id=1 -> marketplace /fragments/agent?id=1
app.get("/fragments/marketplace/:name", async (req, res) => {
  const qs = new URLSearchParams(req.query).toString();
  const url = `${MARKETPLACE_ORIGIN}/fragments/${req.params.name}${qs ? "?" + qs : ""}`;
  try {
    // server-to-server: this is where an auth token / mTLS would be attached.
    const upstream = await fetch(url);
    const body = await upstream.text();
    res
      .status(upstream.status)
      .set("Content-Type", "text/html; charset=utf-8")
      .send(body);
  } catch (err) {
    console.error("[home proxy]", err.message);
    res.status(502).type("html").send("<!-- upstream fragment unavailable -->");
  }
});

let vite;
if (!isProd) {
  const { createServer } = await import("vite");
  vite = await createServer({
    // load home/vite.config.ts (sets root: ./client + react/window-env plugins)
    configFile: path.resolve(__dirname, "../vite.config.ts"),
    server: { middlewareMode: true },
    appType: "spa",
  });
  app.use(vite.middlewares);
} else {
  const clientDist = path.resolve(__dirname, "../dist/client");
  app.use(express.static(clientDist));
  app.get("*", (_req, res) => res.sendFile(path.join(clientDist, "index.html")));
}

app.listen(PORT, () => {
  console.log(
    `[home] ${isProd ? "prod" : "dev"} on http://localhost:${PORT}` +
      `  ->  proxying fragments from ${MARKETPLACE_ORIGIN}`,
  );
});
