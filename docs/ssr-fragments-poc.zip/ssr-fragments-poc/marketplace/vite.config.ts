import { defineConfig, loadEnv, type Plugin } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";

const appRoot = fileURLToPath(new URL(".", import.meta.url)); // marketplace/

// Client side of the env story: read the app-root .env at serve/build time and
// inject the whitelisted vars onto window.env. This is "the vite plugin writes
// it to window" — env.ts then reads window.env in the browser. Only APP_TITLE is
// exposed; nothing else from the environment leaks to the client.
function windowEnv(mode: string): Plugin {
  const env = loadEnv(mode, appRoot, ""); // "" = don't require a VITE_ prefix
  const exposed = { APP_TITLE: env.APP_TITLE ?? "" };
  return {
    name: "window-env",
    transformIndexHtml(html) {
      return html.replace(
        "</head>",
        `  <script>window.env=${JSON.stringify(exposed)}</script>\n  </head>`,
      );
    },
  };
}

// One vite config, two build targets:
//   `vite build`        -> client SPA        -> dist/client
//   `vite build --ssr`  -> fragment renderer -> dist/fragments (node bundle)
// The fragment SSR bundle is emitted straight from the client source tree, so
// the fragment keeps living inside client/src/fragments alongside the very
// components, styles, and config it renders. Nothing has to move into a package.
export default defineConfig(({ mode, isSsrBuild }) => ({
  root: fileURLToPath(new URL("./client", import.meta.url)),
  envDir: appRoot,
  plugins: [react(), windowEnv(mode)],
  build: isSsrBuild
    ? {
        outDir: "../dist/fragments",
        emptyOutDir: true,
        ssr: "src/fragments/entry.server.tsx",
        // Stencil's hydrate module is a prebuilt Node bundle — keep it external
        // (resolved from node_modules at runtime) instead of inlining it.
        rollupOptions: { external: ["@poc/marketplace-fragments/hydrate"] },
      }
    : {
        outDir: "../dist/client",
        emptyOutDir: true,
      },
  // Bundle deps into the SSR output ONLY for the prod build, so `node` can run
  // dist/fragments/entry.server.js standalone. In dev (isSsrBuild=false) React
  // must stay external, or Vite's SSR runner chokes inlining its CommonJS.
  ssr: { noExternal: isSsrBuild },
  server: { port: 3001, hmr: { port: 24678 } },
}));
