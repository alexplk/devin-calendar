import "../fragments/DatasetTile.element"; // registers <dataset-tile> in this SPA
import { listDatasets } from "../capabilities/datasets";
import { getAppTitle } from "../env";
import { tokens } from "@poc/tokens";

// In marketplace's own SPA the datasets live natively: we just render the
// <dataset-tile> custom element directly (definition imported above). Same
// element the fragment ships to home — here rows-url is same-origin.
declare global {
  namespace JSX {
    interface IntrinsicElements {
      "dataset-tile": React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        "data-id"?: string;
        "data-name"?: string;
        "data-description"?: string;
        "data-columns"?: string;
        "data-rows-url"?: string;
      };
    }
  }
}

export function DatasetList() {
  const datasets = listDatasets();
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: tokens.space.lg }}>
      <h1 style={{ fontSize: 22 }}>Marketplace · Datasets</h1>
      <p style={{ color: tokens.color.textMuted, marginTop: 0 }}>
        DatasetTile is a <strong>web component</strong> (no React). SPA env{" "}
        <code>window.env.APP_TITLE</code> = <strong>{getAppTitle()}</strong>.
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {datasets.map((d) => (
          <dataset-tile
            key={d.id}
            data-id={d.id}
            data-name={d.name}
            data-description={d.description}
            data-columns={d.columns.join(",")}
            data-rows-url={`/api/datasets/${d.id}/rows`}
          />
        ))}
      </div>
    </main>
  );
}
