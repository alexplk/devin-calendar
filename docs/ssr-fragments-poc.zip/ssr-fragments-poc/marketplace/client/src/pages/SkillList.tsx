// The "lighter" integration: in marketplace's OWN app we don't need SSR or the
// fragment endpoint — we just IMPORT the compiled Stencil element module. The
// import auto-defines <skill-tile>, and Vite bundles it (and Stencil's runtime)
// into the SPA like any dependency. No hydrate, no wrapper needed for this.
import "@poc/marketplace-fragments/dist/components/skill-tile.js";
import { listSkills } from "../capabilities/skills";
import { getAppTitle } from "../env";
import { tokens } from "@poc/tokens";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "skill-tile": React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        name?: string;
        description?: string;
        level?: string;
        criteria?: string;
        "endorse-url"?: string;
      };
    }
  }
}

export function SkillList() {
  const skills = listSkills();
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: tokens.space.lg }}>
      <h1 style={{ fontSize: 22 }}>Marketplace · Skills</h1>
      <p style={{ color: tokens.color.textMuted, marginTop: 0 }}>
        SkillTile is a <strong>Stencil</strong> web component, imported as a
        module (no SSR). SPA env <code>window.env.APP_TITLE</code> ={" "}
        <strong>{getAppTitle()}</strong>.
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {skills.map((s) => (
          <skill-tile
            key={s.id}
            name={s.name}
            description={s.description}
            level={s.level}
            criteria={s.criteria.join(",")}
            endorse-url={`/api/skills/${s.id}/endorsements`}
          />
        ))}
      </div>
    </main>
  );
}
