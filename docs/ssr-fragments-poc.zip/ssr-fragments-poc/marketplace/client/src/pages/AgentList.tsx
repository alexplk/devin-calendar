import { listAgents } from "../capabilities/agents";
import { AgentTile } from "../components/AgentTile";
import { getAppTitle } from "../env";
import { tokens } from "@poc/tokens";

// Page: mapped to a route, composed from capabilities, otherwise dumb.
// Here it uses AgentTile DIRECTLY as React (the owning app's normal usage).
export function AgentList() {
  const agents = listAgents();
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: tokens.space.lg }}>
      <h1 style={{ fontSize: 22 }}>Marketplace · Agents</h1>
      <p style={{ color: tokens.color.textMuted, marginTop: 0 }}>
        AgentTile used directly as a React component. This SPA reads{" "}
        <code>window.env.APP_TITLE</code> = <strong>{getAppTitle()}</strong>.
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {agents.map((a) => (
          <AgentTile key={a.id} agent={a} />
        ))}
      </div>
    </main>
  );
}
