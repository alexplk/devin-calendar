// In marketplace's own SPA we just register the island's custom element (ESM
// build) and render <tool-tile>. It's authored in React but ships as a Preact
// island; here it runs standalone (same-origin run-url), no SSR, no fragment.
import "@poc/react-fragments/dist/client/tool-tile.es.js";
import { listTools } from "../capabilities/tools";
import { getAppTitle } from "../env";
import { tokens } from "@poc/tokens";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "tool-tile": React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
        name?: string;
        description?: string;
        params?: string;
        "run-url"?: string;
      };
    }
  }
}

export function ToolList() {
  const tools = listTools();
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: tokens.space.lg }}>
      <h1 style={{ fontSize: 22 }}>Marketplace · Tools</h1>
      <p style={{ color: tokens.color.textMuted, marginTop: 0 }}>
        ToolTile is a <strong>React component shipped as a Preact island</strong>.
        SPA env <code>window.env.APP_TITLE</code> = <strong>{getAppTitle()}</strong>.
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
          gap: tokens.space.lg,
        }}
      >
        {tools.map((t) => (
          <tool-tile
            key={t.id}
            name={t.name}
            description={t.description}
            params={t.params.join(",")}
            run-url={`/api/tools/${t.id}/run`}
          />
        ))}
      </div>
    </main>
  );
}
