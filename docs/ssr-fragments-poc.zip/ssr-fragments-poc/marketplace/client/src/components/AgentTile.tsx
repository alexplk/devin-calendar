import { tokens } from "@poc/tokens";
import { getAppTitle } from "../env";

// Dumb, domain-unaware presentational component. Takes an agent-shaped object
// and renders it. Styles are INLINE (from design tokens) so that when this is
// server-rendered into a fragment, the returned HTML is fully self-contained:
// it carries its own look and needs no external stylesheet in the consumer.
export interface Agent {
  id: string;
  name: string;
  description: string;
  category: string;
}

// "Test Server": emitted as raw HTML with an inline onclick, so it survives as
// static markup. getAppTitle() runs AT RENDER TIME and the value is baked into
// the string. Rendered on marketplace's server -> baked "Marketplace", and it
// stays "Marketplace" even embedded in home, because the string is frozen at
// SSR time and the inline handler needs no React.
function serverTestButtonHtml(): string {
  const jsStr = (s: string) => s.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
  const attr = (s: string) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
  const msg = `Test from app ${getAppTitle()}`;
  const style =
    "cursor:pointer;font:inherit;font-size:12px;color:#fff;" +
    `background:${tokens.color.accent};border:none;` +
    `border-radius:${tokens.radius.pill};padding:6px 12px`;
  return `<button type="button" style="${attr(style)}" onclick="alert('${attr(
    jsStr(msg),
  )}')">Test Server</button>`;
}

// "Test Host": inline onclick that reads window.env AT CLICK TIME (not baked).
// So it reports whatever document it's living in — Marketplace in marketplace's
// SPA, Home when embedded in home. This is the host's env, contrast Test Server.
function hostTestButtonHtml(): string {
  const attr = (s: string) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
  const js =
    "alert('Test from app '+((window.env&&window.env.APP_TITLE)||'unknown'))";
  const style =
    "cursor:pointer;font:inherit;font-size:12px;" +
    `color:${tokens.color.text};background:${tokens.color.surfaceMuted};` +
    `border:1px solid ${tokens.color.border};` +
    `border-radius:${tokens.radius.pill};padding:6px 12px`;
  return `<button type="button" style="${attr(style)}" onclick="${attr(
    js,
  )}">Test Host</button>`;
}

const clientButtonStyle: React.CSSProperties = {
  cursor: "pointer",
  font: "inherit",
  fontSize: 12,
  color: tokens.color.accent,
  background: "transparent",
  border: `1px solid ${tokens.color.accent}`,
  borderRadius: tokens.radius.pill,
  padding: "6px 12px",
};

export function AgentTile({ agent }: { agent: Agent }) {
  return (
    <article
      style={{
        boxSizing: "border-box",
        background: tokens.color.surface,
        border: `1px solid ${tokens.color.border}`,
        borderRadius: tokens.radius.md,
        boxShadow: tokens.shadow.card,
        padding: tokens.space.lg,
        fontFamily: tokens.font.family,
        color: tokens.color.text,
        display: "flex",
        flexDirection: "column",
        gap: tokens.space.sm,
        width: "100%",
        maxWidth: 320,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: tokens.space.sm }}>
        <span
          aria-hidden
          style={{
            width: 32,
            height: 32,
            borderRadius: tokens.radius.md,
            background: tokens.color.accentSoft,
            color: tokens.color.accent,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 700,
          }}
        >
          {agent.name.charAt(0)}
        </span>
        <strong style={{ fontSize: 15 }}>{agent.name}</strong>
      </div>
      <p style={{ margin: 0, fontSize: 13, color: tokens.color.textMuted, lineHeight: 1.4 }}>
        {agent.description}
      </p>
      <span
        style={{
          alignSelf: "flex-start",
          fontSize: 11,
          textTransform: "uppercase",
          letterSpacing: 0.4,
          color: tokens.color.accent,
          background: tokens.color.accentSoft,
          borderRadius: tokens.radius.pill,
          padding: `${tokens.space.xs} ${tokens.space.sm}`,
        }}
      >
        {agent.category}
      </span>

      <div
        style={{
          display: "flex",
          gap: tokens.space.sm,
          marginTop: tokens.space.xs,
          flexWrap: "wrap",
        }}
      >
        {/* Test Server: inline-onclick HTML, title baked at render time
            (owner's env when SSR'd). */}
        <span dangerouslySetInnerHTML={{ __html: serverTestButtonHtml() }} />
        {/* Test Host: inline-onclick, reads window.env at click (host's env). */}
        <span dangerouslySetInnerHTML={{ __html: hostTestButtonHtml() }} />
        {/* Test Client: a normal React handler. Only runs where React drives
            this component — marketplace's SPA, or a fragment after it's been
            hydrated in the host. Inert in a static embed. */}
        <button
          type="button"
          style={clientButtonStyle}
          onClick={() => alert(`Test from app ${getAppTitle()}`)}
        >
          Test Client
        </button>
      </div>
    </article>
  );
}
