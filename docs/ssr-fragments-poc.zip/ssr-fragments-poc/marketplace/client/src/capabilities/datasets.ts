// Capability: domain-aware dataset data. Sample data for the POC; a real one
// would fetch through the server's proxy. Used by the marketplace DatasetList
// page, the SSR dataset fragment, and the rows API.
export interface Dataset {
  id: string;
  name: string;
  description: string;
  columns: string[];
}

const DATASETS: Record<string, Dataset> = {
  "1": {
    id: "1",
    name: "Customer Contracts",
    description: "Signed agreements with values, terms and renewal dates.",
    columns: ["id", "customer", "value", "renews_on"],
  },
  "2": {
    id: "2",
    name: "Support Tickets",
    description: "Inbound tickets with status, priority and assignee.",
    columns: ["id", "subject", "priority", "status"],
  },
  "3": {
    id: "3",
    name: "Model Runs",
    description: "Evaluation runs with accuracy, latency and cost.",
    columns: ["id", "model", "accuracy", "cost_usd"],
  },
  "4": {
    id: "4",
    name: "Invoices",
    description: "Issued invoices with amounts and payment state.",
    columns: ["id", "account", "amount", "paid"],
  },
};

const ROWS: Record<string, Record<string, string | number>[]> = {
  "1": [
    { id: "C-1042", customer: "Northwind", value: "$48,000", renews_on: "2026-09-01" },
    { id: "C-1043", customer: "Contoso", value: "$12,500", renews_on: "2026-07-15" },
    { id: "C-1051", customer: "Fabrikam", value: "$96,200", renews_on: "2027-01-30" },
  ],
  "2": [
    { id: "T-88", subject: "Login loop", priority: "High", status: "Open" },
    { id: "T-90", subject: "Export fails", priority: "Med", status: "Triage" },
    { id: "T-91", subject: "Typo in modal", priority: "Low", status: "Closed" },
  ],
  "3": [
    { id: "R-5", model: "opus-4.8", accuracy: "0.94", cost_usd: "1.20" },
    { id: "R-6", model: "sonnet-5", accuracy: "0.91", cost_usd: "0.35" },
    { id: "R-7", model: "haiku-4.5", accuracy: "0.86", cost_usd: "0.08" },
  ],
  "4": [
    { id: "INV-301", account: "Northwind", amount: "$4,000", paid: "yes" },
    { id: "INV-302", account: "Contoso", amount: "$1,250", paid: "no" },
  ],
};

export function listDatasets(): Dataset[] {
  return Object.values(DATASETS);
}
export function getDataset(id: string): Dataset | undefined {
  return DATASETS[id];
}
export function getDatasetRows(id: string): Record<string, string | number>[] {
  return ROWS[id] ?? [];
}
