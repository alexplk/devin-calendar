// Capability: MCP tool data (lives in marketplace, the owner). Passed to the
// ToolTile island as attributes at SSR; results come from the run API.
export interface Tool {
  id: string;
  name: string;
  description: string;
  params: string[];
}

const TOOLS: Record<string, Tool> = {
  "1": {
    id: "1",
    name: "search_web",
    description: "Search the web and return ranked result snippets.",
    params: ["query", "max_results"],
  },
  "2": {
    id: "2",
    name: "read_file",
    description: "Read a file from the workspace and return its contents.",
    params: ["path", "offset", "limit"],
  },
  "3": {
    id: "3",
    name: "run_sql",
    description: "Execute a read-only SQL query against the warehouse.",
    params: ["query", "timeout_ms"],
  },
  "4": {
    id: "4",
    name: "send_email",
    description: "Draft and send an email on the user's behalf.",
    params: ["to", "subject", "body"],
  },
};

const RESULTS: Record<string, string> = {
  "1": '{"results":[{"title":"MCP spec","score":0.98},{"title":"Tool use","score":0.91}]}',
  "2": '{"bytes":2048,"lines":64,"preview":"import { ... } from ..."}',
  "3": '{"rows":3,"elapsed_ms":42,"columns":["id","total"]}',
  "4": '{"status":"queued","message_id":"msg_8f21"}',
};

export function listTools(): Tool[] {
  return Object.values(TOOLS);
}
export function getTool(id: string): Tool | undefined {
  return TOOLS[id];
}
export function getToolResult(id: string): string {
  return RESULTS[id] ?? "{}";
}
