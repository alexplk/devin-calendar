import type { Agent } from "../components/AgentTile";

// Capability: domain-aware data access. In the real app this would hit an API
// (through the server's proxy) and read env config. Here it's sample data so the
// POC has something to render. Used by BOTH the AgentList page (client) and the
// Agent fragment renderer (server) — the fragment is just another consumer of
// the same capability, rendered in a different place.
const AGENTS: Record<string, Agent> = {
  "1": {
    id: "1",
    name: "Contract Analyzer",
    description: "Extracts clauses, obligations and renewal dates from legal PDFs.",
    category: "Legal",
  },
  "2": {
    id: "2",
    name: "Incident Triage",
    description: "Classifies incoming alerts and drafts a first-response summary.",
    category: "Ops",
  },
  "3": {
    id: "3",
    name: "Data Profiler",
    description: "Scans a dataset and reports schema, nulls and outliers.",
    category: "Data",
  },
  "4": {
    id: "4",
    name: "Meeting Scribe",
    description: "Turns a call transcript into decisions, owners and action items.",
    category: "Productivity",
  },
};

export function listAgents(): Agent[] {
  return Object.values(AGENTS);
}

export function getAgent(id: string): Agent | undefined {
  return AGENTS[id];
}
