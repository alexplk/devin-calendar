// Capability: domain-aware skill data. Lives in marketplace (the owner). The
// SkillTile web component is dumb — this data is passed to it as attributes at
// SSR and via the endorsements fetch. Used by the SkillList page, the skill
// fragment (SSR), and the endorsements API.
export interface Skill {
  id: string;
  name: string;
  description: string;
  level: string;
  criteria: string[];
}

const SKILLS: Record<string, Skill> = {
  "1": {
    id: "1",
    name: "Prompt Engineering",
    description: "Designing and evaluating prompts for reliable agent behaviour.",
    level: "Advanced",
    criteria: ["Few-shot design", "Eval harness", "Failure analysis"],
  },
  "2": {
    id: "2",
    name: "Retrieval (RAG)",
    description: "Chunking, embedding and grounding answers in sources.",
    level: "Intermediate",
    criteria: ["Chunking strategy", "Reranking", "Citations"],
  },
  "3": {
    id: "3",
    name: "Tool Calling",
    description: "Wiring agents to typed tools with safe argument handling.",
    level: "Advanced",
    criteria: ["Schema design", "Validation", "Error recovery"],
  },
  "4": {
    id: "4",
    name: "Observability",
    description: "Tracing, metrics and cost tracking for agent runs.",
    level: "Beginner",
    criteria: ["Tracing", "Token accounting", "Dashboards"],
  },
};

const ENDORSERS: Record<string, string[]> = {
  "1": ["Ada", "Linus", "Grace", "Alan"],
  "2": ["Barbara", "Edsger", "Ken"],
  "3": ["Margaret", "Dennis", "Radia", "Vint"],
  "4": ["Katherine", "Tim"],
};

export function listSkills(): Skill[] {
  return Object.values(SKILLS);
}
export function getSkill(id: string): Skill | undefined {
  return SKILLS[id];
}
export function getSkillEndorsers(id: string): string[] {
  return ENDORSERS[id] ?? [];
}
