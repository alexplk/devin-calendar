import { renderToString } from "react-dom/server";
// Stencil's SSR renderer for the SkillTile web component (from the compiled
// packages/fragments hydrate output). External in the SSR build (see vite.config).
import { renderToString as renderStencil } from "@poc/marketplace-fragments/hydrate";
import { getAgent } from "../capabilities/agents";
import { getDataset, getDatasetRows } from "../capabilities/datasets";
import type { Dataset } from "../capabilities/datasets";
import { getSkill, getSkillEndorsers } from "../capabilities/skills";
import type { Skill } from "../capabilities/skills";
import { getTool, getToolResult } from "../capabilities/tools";
import { AgentFragment } from "./Agent";
import type { Agent } from "../components/AgentTile";

// Re-export so the server can serve these data APIs / read tool data through the
// same module it already loads (dev: ssrLoadModule, prod: built bundle). The
// Tool tier renders in its own middleware (Preact), but its DATA still lives in
// this app, so it's exposed here.
export { getDatasetRows, getSkillEndorsers, getTool, getToolResult };

// SSR entry for fragments. Loaded by express (dev: vite.ssrLoadModule; prod:
// the built dist/fragments bundle) to turn a fragment name + query into HTML.

// Browser-reachable origin of THIS app, used only for the on-demand hydration
// script src. (Loading it cross-app is exactly the coupling the static fragment
// avoids — see README.)
const PUBLIC_ORIGIN = process.env.PUBLIC_ORIGIN || "http://localhost:3001";

type Query = Record<string, string | string[] | undefined>;
const str = (v: Query[string]) => (Array.isArray(v) ? v[0] : v) ?? "";

// Self-contained Hydrate control. Lives in the fragment wrapper (not in the
// tile) and carries everything it needs inline — no events between tile and
// host. On click it loads marketplace's fragment-client bundle (once) and
// mounts a live AgentTile over the static markup.
function hydrateButton(targetId: string): string {
  const src = `${PUBLIC_ORIGIN}/fragment-client/agent.js`;
  const js = [
    `var el=document.getElementById('${targetId}');`,
    `var p=JSON.parse(document.getElementById('${targetId}-props').textContent);`,
    `function go(){window.__MKT_FRAG__.hydrateAgent(el,p);}`,
    `if(window.__MKT_FRAG__){go();}`,
    `else{var s=document.createElement('script');s.src='${src}';s.onload=go;document.head.appendChild(s);}`,
  ].join("");
  const style =
    "cursor:pointer;font:inherit;font-size:12px;color:#1a1d23;" +
    "background:#f5f6f8;border:1px solid #e4e7ec;border-radius:999px;padding:6px 12px";
  // js uses only single quotes, so it is safe inside the double-quoted attribute
  return `<button type="button" style="${style}" onclick="${js.replace(
    /"/g,
    "&quot;",
  )}">Hydrate this tile</button>`;
}

function renderAgent(agent: Agent): string {
  const id = `mkt-agent-${agent.id}`;
  const tile = renderToString(<AgentFragment agent={agent} />);
  const props = JSON.stringify(agent).replace(/</g, "\\u003c");
  return (
    `<div style="display:flex;flex-direction:column;gap:8px">` +
    `<div id="${id}">${tile}</div>` +
    `<div>${hydrateButton(id)}</div>` +
    `<script type="application/json" id="${id}-props">${props}</script>` +
    `</div>`
  );
}

// Dataset fragment: no React, no hydrate button. It emits the <dataset-tile>
// custom element with a light-DOM fallback (title + description) so it's
// readable before the definition loads. Once the consumer has loaded
// dataset-tile.js once, this and every other instance upgrade automatically.
const attr = (s: string) => String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;");
const html = (s: string) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

function renderDataset(ds: Dataset): string {
  const rowsUrl = `${PUBLIC_ORIGIN}/api/datasets/${ds.id}/rows`;
  const fallback =
    `<article style="box-sizing:border-box;background:#fff;border:1px solid #e4e7ec;border-radius:10px;` +
    `box-shadow:0 1px 2px rgba(16,24,40,0.06);padding:16px;font-family:system-ui,sans-serif;` +
    `display:flex;flex-direction:column;gap:8px;max-width:320px">` +
    `<strong style="font-size:15px">${html(ds.name)}</strong>` +
    `<p style="margin:0;font-size:13px;color:#667085">${html(ds.description)}</p>` +
    `<span style="font-size:11px;color:#667085">Dataset · enhancing…</span></article>`;
  return (
    `<dataset-tile data-id="${attr(ds.id)}" data-name="${attr(ds.name)}" ` +
    `data-description="${attr(ds.description)}" data-columns="${attr(ds.columns.join(","))}" ` +
    `data-rows-url="${attr(rowsUrl)}">${fallback}</dataset-tile>`
  );
}

// Skill fragment: a Stencil web component, SERVER-RENDERED with Stencil's own
// renderToString (real SSR of the component, not just a fallback). Home embeds
// the produced markup; loading the definition once then hydrates it in place.
async function renderSkill(sk: Skill): Promise<string> {
  const endorseUrl = `${PUBLIC_ORIGIN}/api/skills/${sk.id}/endorsements`;
  const markup =
    `<skill-tile name="${attr(sk.name)}" description="${attr(sk.description)}" ` +
    `level="${attr(sk.level)}" criteria="${attr(sk.criteria.join(","))}" ` +
    `endorse-url="${attr(endorseUrl)}"></skill-tile>`;
  const { html: out } = await renderStencil(markup, { fullDocument: false });
  return out;
}

const registry: Record<string, (q: Query) => string | Promise<string>> = {
  // GET /fragments/agent?id=1   — React SSR + manual hydrate (federation-shaped)
  agent(q) {
    const agent = getAgent(str(q.id));
    if (!agent) throw Object.assign(new Error("agent not found"), { status: 404 });
    return renderAgent(agent);
  },
  // GET /fragments/dataset?id=1 — hand-rolled web component, auto-upgrades
  dataset(q) {
    const ds = getDataset(str(q.id));
    if (!ds) throw Object.assign(new Error("dataset not found"), { status: 404 });
    return renderDataset(ds);
  },
  // GET /fragments/skill?id=1   — Stencil web component, SSR'd via hydrate
  skill(q) {
    const sk = getSkill(str(q.id));
    if (!sk) throw Object.assign(new Error("skill not found"), { status: 404 });
    return renderSkill(sk);
  },
};

export async function renderFragment(name: string, query: Query): Promise<string> {
  const render = registry[name];
  if (!render) throw Object.assign(new Error(`unknown fragment: ${name}`), { status: 404 });
  return await render(query);
}
