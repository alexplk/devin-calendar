import { tokens as t } from "@poc/tokens";

// DatasetTile — a framework-agnostic Web Component (Custom Element).
//
// This is the "light interactive widget" tier: the producing pod authors a
// standard custom element; the consumer loads this definition ONCE and every
// <dataset-tile> in the page — including ones injected later as fragment HTML —
// upgrades automatically via connectedCallback. No React, no shared singleton,
// works the same in Vite or Astro. Config is baked into data-* attributes at
// SSR time, so the element stays "clueless": it only reads its own attributes.
//
// Interactivity demonstrated: expand/collapse the column list (pure DOM) and a
// "Preview rows" fetch with an in-progress spinner (data-rows-url baked in).

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const SPIN_ID = "poc-spin-style";
function ensureSpinnerStyle() {
  if (document.getElementById(SPIN_ID)) return;
  const s = document.createElement("style");
  s.id = SPIN_ID;
  s.textContent =
    "@keyframes poc-spin{to{transform:rotate(360deg)}}" +
    `.poc-spin{display:inline-block;width:13px;height:13px;border:2px solid ${t.color.border};` +
    `border-top-color:${t.color.accent};border-radius:50%;animation:poc-spin .7s linear infinite;vertical-align:middle}`;
  document.head.appendChild(s);
}

class DatasetTile extends HTMLElement {
  private upgraded = false;

  connectedCallback() {
    if (this.upgraded) return; // guard: connectedCallback can fire more than once
    this.upgraded = true;
    ensureSpinnerStyle();

    const name = this.getAttribute("data-name") ?? "";
    const desc = this.getAttribute("data-description") ?? "";
    const columns = (this.getAttribute("data-columns") ?? "").split(",").filter(Boolean);
    const rowsUrl = this.getAttribute("data-rows-url") ?? "";

    this.innerHTML = `
      <article style="box-sizing:border-box;background:${t.color.surface};border:1px solid ${t.color.border};border-radius:${t.radius.md};box-shadow:${t.shadow.card};padding:${t.space.lg};font-family:${t.font.family};color:${t.color.text};display:flex;flex-direction:column;gap:${t.space.sm};width:100%;max-width:320px">
        <div style="display:flex;align-items:center;gap:${t.space.sm}">
          <span aria-hidden style="width:32px;height:32px;border-radius:${t.radius.md};background:${t.color.accentSoft};color:${t.color.accent};display:inline-flex;align-items:center;justify-content:center;font-weight:700">▦</span>
          <strong style="font-size:15px">${esc(name)}</strong>
        </div>
        <p style="margin:0;font-size:13px;color:${t.color.textMuted};line-height:1.4">${esc(desc)}</p>
        <span style="align-self:flex-start;font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:${t.color.accent};background:${t.color.accentSoft};border-radius:${t.radius.pill};padding:${t.space.xs} ${t.space.sm}">Dataset · web component</span>
        <div style="display:flex;gap:${t.space.sm};flex-wrap:wrap">
          <button data-el="toggle" type="button" style="cursor:pointer;font:inherit;font-size:12px;color:${t.color.accent};background:transparent;border:1px solid ${t.color.accent};border-radius:${t.radius.pill};padding:6px 12px">Columns ▾</button>
          <button data-el="preview" type="button" style="cursor:pointer;font:inherit;font-size:12px;color:#fff;background:${t.color.accent};border:none;border-radius:${t.radius.pill};padding:6px 12px">Preview rows</button>
        </div>
        <ul data-el="columns" hidden style="margin:2px 0 0;padding-left:18px;font-size:12px;color:${t.color.textMuted}">${columns
          .map((c) => `<li>${esc(c)}</li>`)
          .join("")}</ul>
        <div data-el="rows" style="font-size:12px;color:${t.color.textMuted}"></div>
      </article>`;

    const toggle = this.querySelector('[data-el="toggle"]') as HTMLButtonElement;
    const cols = this.querySelector('[data-el="columns"]') as HTMLElement;
    toggle.addEventListener("click", () => {
      const show = cols.hidden;
      cols.hidden = !show;
      toggle.textContent = show ? "Columns ▴" : "Columns ▾";
    });

    const preview = this.querySelector('[data-el="preview"]') as HTMLButtonElement;
    const out = this.querySelector('[data-el="rows"]') as HTMLElement;
    preview.addEventListener("click", async () => {
      preview.disabled = true;
      out.innerHTML = `<span class="poc-spin"></span> <span style="vertical-align:middle">Loading rows…</span>`;
      try {
        const res = await fetch(rowsUrl);
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        const rows: Record<string, string | number>[] = data.rows ?? [];
        out.innerHTML = `<table style="border-collapse:collapse;margin-top:4px;font-size:12px">${rows
          .map(
            (r) =>
              `<tr>${Object.values(r)
                .map(
                  (v) =>
                    `<td style="border:1px solid ${t.color.border};padding:2px 6px">${esc(String(v))}</td>`,
                )
                .join("")}</tr>`,
          )
          .join("")}</table>`;
      } catch {
        out.innerHTML = `<span style="color:#b42318">Failed to load rows</span>`;
      } finally {
        preview.disabled = false;
      }
    });
  }
}

if (!customElements.get("dataset-tile")) {
  customElements.define("dataset-tile", DatasetTile);
}
