import { AgentTile, type Agent } from "../components/AgentTile";

// Fragment: like a page, but for delivering a capability's output to an EXTERNAL
// caller (another app) as embeddable HTML. Dumb logistics only — it takes the
// data it was given and renders the real component. No routing, no interactivity.
export function AgentFragment({ agent }: { agent: Agent }) {
  return <AgentTile agent={agent} />;
}
