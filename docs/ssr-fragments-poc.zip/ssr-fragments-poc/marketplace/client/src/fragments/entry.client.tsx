import { createRoot } from "react-dom/client";
import { AgentFragment } from "./Agent";
import type { Agent } from "../components/AgentTile";

// Client entry for ON-DEMAND HYDRATION. Bundled by the server into a
// self-contained IIFE (React included) and served at /fragment-client/agent.js,
// exposed on the page as window.__MKT_FRAG__.
//
// The fragment's "Hydrate" button loads this and calls hydrateAgent(el, props)
// to mount a LIVE AgentTile over the static markup — the embed becomes
// interactive. This is where the cross-app coupling reappears: the consumer now
// has to load marketplace's component code + a second React into its own page.
//
// It also runs in the HOST's window, so from this point the tile reads the
// HOST's window.env (Home), not marketplace's — the config boundary flips.
//
// (We use createRoot().render rather than hydrateRoot on purpose: a true
// hydrate would flag a mismatch precisely because the server baked the owner's
// env and the client re-renders with the host's — which is itself the lesson.)
export function hydrateAgent(el: HTMLElement, props: Agent) {
  createRoot(el).render(<AgentFragment agent={props} />);
}
