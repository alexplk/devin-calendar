import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "@poc/tokens/tokens.css";
import { AgentList } from "./pages/AgentList";
import { DatasetList } from "./pages/DatasetList";
import { SkillList } from "./pages/SkillList";
import { ToolList } from "./pages/ToolList";

// Marketplace SPA. All listings on one page for the POC (no router needed).
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <AgentList />
    <DatasetList />
    <SkillList />
    <ToolList />
  </StrictMode>,
);
