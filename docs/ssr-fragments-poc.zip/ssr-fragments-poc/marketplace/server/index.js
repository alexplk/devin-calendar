import "dotenv/config"; // loads ./.env into process.env (server-side env source)
import express from "express";
import path from "node:path";
import { createRuntime, isProd, appRoot, PORT } from "./runtime.js";
import { agentApproach } from "./approaches/agent.js";
import { datasetApproach } from "./approaches/dataset.js";
import { skillApproach } from "./approaches/skill.js";
import { toolApproach } from "./approaches/tool.js";

// Marketplace server. The app's own concerns (api proxies, etc.) would live
// here; the interesting part is the four fragment-delivery approaches, each
// isolated in its own router so you can read one file and see exactly what that
// tier costs on the server.
const app = express();
const ctx = await createRuntime();

// --- app api proxies would be registered here (unchanged by fragments) ---

app.use(agentApproach(ctx)); //   React SSR + 146 KB hydrate bundle
app.use(datasetApproach(ctx)); // vanilla web component (4 KB) + rows API
app.use(skillApproach(ctx)); //   Stencil web component (24 KB) + endorsements API
app.use(toolApproach(ctx)); //    Preact island, SSR'd (~10 KB) + run API

// SPA: Vite in dev, static in prod.
if (isProd) {
  const clientDist = path.join(appRoot, "dist/client");
  app.use(express.static(clientDist));
  app.get("*", (_req, res) => res.sendFile(path.join(clientDist, "index.html")));
} else {
  app.use(ctx.vite.middlewares);
}

app.listen(PORT, () => {
  console.log(
    `[marketplace] ${isProd ? "prod" : "dev"} on http://localhost:${PORT}` +
      `  (fragments: agent, dataset, skill, tool)`,
  );
});
