import esbuild from "esbuild";
import path from "node:path";
import { fileURLToPath } from "node:url";

// Shared plumbing used by every approach middleware. Kept small on purpose so
// each approaches/*.js file shows only that tier's own server code.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const isProd = process.env.NODE_ENV === "production";
export const appRoot = path.resolve(__dirname, ".."); // marketplace/
export const PORT = process.env.PORT || 3001;
const PUBLIC_ORIGIN = process.env.PUBLIC_ORIGIN || "http://localhost:3001";

const attr = (s) => String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;");
const str = (v) => (Array.isArray(v) ? v[0] : v) ?? "";

export async function createRuntime() {
  let vite;
  let prodMod;
  if (!isProd) {
    const { createServer } = await import("vite");
    vite = await createServer({
      configFile: path.join(appRoot, "vite.config.ts"),
      server: { middlewareMode: true },
      appType: "spa",
    });
  } else {
    prodMod = await import(path.join(appRoot, "dist/fragments/entry.server.js"));
  }

  // The app's SSR module (agent/dataset/skill renderers + capability data).
  // dev: read live from source via Vite; prod: the built bundle.
  const fragmentModule = async () =>
    isProd ? prodMod : await vite.ssrLoadModule("/src/fragments/entry.server.tsx");

  // esbuild a browser IIFE — used by approaches that bundle their own client.
  const iifeBundle = async (input) =>
    (
      await esbuild.build({
        ...input,
        bundle: true,
        write: false,
        format: "iife",
        platform: "browser",
        minify: true,
        define: { "process.env.NODE_ENV": '"production"' },
      })
    ).outputFiles[0].text;

  const sendJs = (res, js) =>
    res.type("application/javascript").set("Access-Control-Allow-Origin", "*").send(js);
  const json = (res, obj) => res.set("Access-Control-Allow-Origin", "*").json(obj);

  // Wrap a fragment renderer with the shared status/cache/fallback handling.
  const fragmentRoute = (name, render) => async (req, res) => {
    try {
      const html = await render(req);
      res
        .status(200)
        .set("Content-Type", "text/html; charset=utf-8")
        .set("Cache-Control", "public, max-age=30")
        .send(html);
    } catch (err) {
      if (vite) vite.ssrFixStacktrace(err);
      console.error(`[fragment ${name}]`, err.message);
      res
        .status(err?.status ?? 500)
        .type("html")
        .send(`<!-- fragment "${name}" unavailable -->`);
    }
  };

  return {
    isProd, appRoot, path, vite,
    fragmentModule, iifeBundle, sendJs, json, fragmentRoute,
    PUBLIC_ORIGIN, attr, str,
  };
}
