import { Router } from "express";

// SKILL tier — Stencil web component.
// Server code: render via Stencil's SSR (inside the app SSR module); serve the
// ~24 KB compiled element (esbuild-bundled from the Stencil dist); endorsements API.
export function skillApproach(ctx) {
  const r = Router();
  let clientJs;

  r.get(
    "/fragments/skill",
    ctx.fragmentRoute("skill", async (req) =>
      (await ctx.fragmentModule()).renderFragment("skill", req.query),
    ),
  );

  r.get("/fragment-client/skill-tile.js", async (_req, res) => {
    clientJs ??= await ctx.iifeBundle({
      stdin: {
        contents: "import './skill-tile.js';", // auto-defines on import
        resolveDir: ctx.path.join(ctx.appRoot, "packages/fragments/dist/components"),
        loader: "js",
      },
    });
    ctx.sendJs(res, clientJs);
  });

  r.get("/api/skills/:id/endorsements", async (req, res) => {
    const { getSkillEndorsers } = await ctx.fragmentModule();
    await new Promise((x) => setTimeout(x, 400));
    ctx.json(res, { endorsers: getSkillEndorsers(req.params.id) });
  });

  return r;
}
