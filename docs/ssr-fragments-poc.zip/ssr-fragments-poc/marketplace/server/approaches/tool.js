import { Router } from "express";
import { readFileSync } from "node:fs";
// The island's SSR renderer (Preact) — a prebuilt package, imported directly.
// This is the "server side change" for this tier: SSR is preact-render-to-string.
import { renderTool } from "@poc/react-fragments/ssr";

// TOOL tier — React island shipped as Preact.
// Server code: SSR the island with Preact and wrap it in <tool-tile>; serve the
// ~10 KB IIFE (prebuilt by the island's own Vite build); run API. Note this
// tier renders in its OWN package (renderTool), not the app SSR module — only
// the tool DATA comes from the app.
export function toolApproach(ctx) {
  const r = Router();
  const clientJs = readFileSync(
    ctx.path.join(ctx.appRoot, "packages/react-fragments/dist/client/tool-tile.iife.js"),
    "utf8",
  );

  r.get(
    "/fragments/tool",
    ctx.fragmentRoute("tool", async (req) => {
      const { getTool } = await ctx.fragmentModule();
      const t = getTool(ctx.str(req.query.id));
      if (!t) throw Object.assign(new Error("tool not found"), { status: 404 });
      const runUrl = `${ctx.PUBLIC_ORIGIN}/api/tools/${t.id}/run`;
      const props = {
        name: t.name,
        description: t.description,
        params: t.params.join(","),
        runUrl,
      };
      const inner = renderTool(props); // Preact SSR of the island's markup
      return (
        `<tool-tile name="${ctx.attr(t.name)}" description="${ctx.attr(t.description)}" ` +
        `params="${ctx.attr(props.params)}" run-url="${ctx.attr(runUrl)}">${inner}</tool-tile>`
      );
    }),
  );

  r.get("/fragment-client/tool-tile.js", (_req, res) => ctx.sendJs(res, clientJs));

  r.get("/api/tools/:id/run", async (req, res) => {
    const { getToolResult } = await ctx.fragmentModule();
    await new Promise((x) => setTimeout(x, 400));
    ctx.json(res, { result: getToolResult(req.params.id) });
  });

  return r;
}
