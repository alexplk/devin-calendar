import { Router } from "express";

// DATASET tier — hand-rolled vanilla web component.
// Server code: render the light-DOM fragment; serve the ~4 KB element; rows API.
export function datasetApproach(ctx) {
  const r = Router();
  let clientJs;

  r.get(
    "/fragments/dataset",
    ctx.fragmentRoute("dataset", async (req) =>
      (await ctx.fragmentModule()).renderFragment("dataset", req.query),
    ),
  );

  r.get("/fragment-client/dataset-tile.js", async (_req, res) => {
    clientJs ??= await ctx.iifeBundle({
      entryPoints: [
        ctx.path.join(ctx.appRoot, "client/src/fragments/DatasetTile.element.ts"),
      ],
    });
    ctx.sendJs(res, clientJs);
  });

  r.get("/api/datasets/:id/rows", async (req, res) => {
    const { getDatasetRows } = await ctx.fragmentModule();
    await new Promise((x) => setTimeout(x, 400)); // let the spinner show
    ctx.json(res, { rows: getDatasetRows(req.params.id) });
  });

  return r;
}
