import { Router } from "express";

// AGENT tier — React SSR + on-demand hydrate (federation-shaped).
// Server code: render via the app's SSR module; serve the React hydrate bundle
// (~146 KB, bundles React). The heaviest client, the richest interop.
export function agentApproach(ctx) {
  const r = Router();
  let clientJs;

  r.get(
    "/fragments/agent",
    ctx.fragmentRoute("agent", async (req) =>
      (await ctx.fragmentModule()).renderFragment("agent", req.query),
    ),
  );

  r.get("/fragment-client/agent.js", async (_req, res) => {
    clientJs ??= await ctx.iifeBundle({
      entryPoints: [
        ctx.path.join(ctx.appRoot, "client/src/fragments/entry.client.tsx"),
      ],
      globalName: "__MKT_FRAG__",
      jsx: "automatic",
    });
    ctx.sendJs(res, clientJs);
  });

  return r;
}
