import { Config } from "@stencil/core";

// Stencil is its OWN compiler — this package is built with `stencil build`, not
// Vite. That's exactly why it lives in marketplace/packages/ rather than in
// marketplace/client/src: a Vite app can't compile Stencil source.
//
// Outputs:
//  - dist-custom-elements: framework-agnostic custom elements (auto-define on
//    import). Consumed directly by marketplace's React SPA (Vite bundles it) and
//    esbuild-bundled into a standalone script for cross-app loading by home.
//  - dist-hydrate-script: a Node renderToString() used by marketplace's server
//    to SSR the tile for home's fragment.
export const config: Config = {
  namespace: "marketplace-fragments",
  outputTargets: [
    {
      type: "dist-custom-elements",
      customElementsExportBehavior: "auto-define-custom-elements",
      externalRuntime: false,
    },
    { type: "dist-hydrate-script", dir: "hydrate" },
  ],
};
