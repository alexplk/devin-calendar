import { Component, Prop, State, h, Host } from "@stencil/core";

// SkillTile — authored in Stencil (TSX + decorators, compiled to a standards
// custom element). Dumb + attribute-driven: it never imports marketplace app
// code. Data comes in via props (baked as attributes at SSR) and the
// endorsements fetch (URL baked in). Styling uses the fleet-wide token CSS
// variables, and `scoped: true` keeps it in light DOM so those tokens apply.
@Component({
  tag: "skill-tile",
  styleUrl: "skill-tile.css",
  scoped: true,
})
export class SkillTile {
  @Prop() name = "";
  @Prop() description = "";
  @Prop() level = "";
  @Prop() criteria = ""; // comma-separated
  @Prop() endorseUrl = ""; // attribute: endorse-url

  @State() private open = false;
  @State() private loading = false;
  @State() private endorsers: string[] = [];
  @State() private error = false;

  private toggle = () => {
    this.open = !this.open;
  };

  private load = async () => {
    this.loading = true;
    this.error = false;
    try {
      const res = await fetch(this.endorseUrl);
      if (!res.ok) throw new Error(String(res.status));
      this.endorsers = (await res.json()).endorsers ?? [];
    } catch {
      this.error = true;
    } finally {
      this.loading = false;
    }
  };

  render() {
    const criteria = this.criteria
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    return (
      <Host>
        <article class="tile">
          <div class="head">
            <span class="mark" aria-hidden>
              ★
            </span>
            <strong>{this.name}</strong>
            {this.level ? <span class="level">{this.level}</span> : null}
          </div>
          <p class="desc">{this.description}</p>
          <span class="tag">Skill · Stencil web component</span>
          <div class="actions">
            <button class="secondary" onClick={this.toggle}>
              {this.open ? "Criteria ▴" : "Criteria ▾"}
            </button>
            <button class="primary" onClick={this.load} disabled={this.loading}>
              {this.loading ? "Loading…" : "Endorsements"}
            </button>
          </div>
          {this.open ? (
            <ul class="criteria">
              {criteria.map((c) => (
                <li>{c}</li>
              ))}
            </ul>
          ) : null}
          {this.error ? <span class="err">Failed to load</span> : null}
          {this.endorsers.length > 0 ? (
            <div class="endorsers">
              {this.endorsers.length} endorsements: {this.endorsers.join(", ")}
            </div>
          ) : null}
        </article>
      </Host>
    );
  }
}
