import { defineConfig } from "vite";
import preact from "@preact/preset-vite";

// A "React island" built as its OWN tiny Vite module. We author in React
// (hooks/JSX) but alias react -> preact/compat, so the shipped runtime is
// Preact (~4 KB) instead of React (~45 KB gzip). No new framework, no separate
// compiler — plain Vite builds it. Two outputs:
//   client: the custom-element wrapper as a self-contained IIFE (cross-app) and
//           an ESM build (imported by marketplace's own SPA).
//   ssr:    preact-render-to-string entry, imported by the server to SSR the tile.
export default defineConfig(({ isSsrBuild }) => ({
  plugins: [preact()],
  build: isSsrBuild
    ? { outDir: "dist/ssr", ssr: "src/fragments/server.tsx", emptyOutDir: true }
    : {
        outDir: "dist/client",
        emptyOutDir: true,
        minify: true,
        lib: {
          entry: "src/fragments/tool-tile.element.ts",
          formats: ["iife", "es"],
          name: "ToolTileEl",
          fileName: (format) => `tool-tile.${format}.js`,
        },
      },
}));
