import { renderToString } from "preact-render-to-string";
import { h } from "preact";
import { ToolTile, type ToolProps } from "./ToolTile";

// SSR entry (Preact). The marketplace server imports this to server-render the
// island's inner markup, which it wraps in <tool-tile> for the fragment.
export function renderTool(props: ToolProps): string {
  return renderToString(h(ToolTile as any, props));
}
