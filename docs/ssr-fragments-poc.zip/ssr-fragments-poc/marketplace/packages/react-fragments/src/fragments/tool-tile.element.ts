import { h, hydrate, render } from "preact";
import { ToolTile } from "./ToolTile";

// Thin custom-element wrapper so the React island gets web-component ergonomics:
// auto-upgrade on injection (connectedCallback), attributes in. On connect it
// reads its attributes and mounts the ToolTile island — hydrating the SSR markup
// if present, else rendering fresh. This is the only glue; the component is
// plain React.
class ToolTileEl extends HTMLElement {
  private mounted = false;
  connectedCallback() {
    if (this.mounted) return;
    this.mounted = true;
    const props = {
      name: this.getAttribute("name") ?? "",
      description: this.getAttribute("description") ?? "",
      params: this.getAttribute("params") ?? "",
      runUrl: this.getAttribute("run-url") ?? "",
    };
    const vnode = h(ToolTile as any, props);
    if (this.firstElementChild) hydrate(vnode, this);
    else render(vnode, this);
  }
}

if (!customElements.get("tool-tile")) {
  customElements.define("tool-tile", ToolTileEl);
}
