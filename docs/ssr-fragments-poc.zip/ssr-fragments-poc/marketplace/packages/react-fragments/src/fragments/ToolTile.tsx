import { useState } from "react";

// ToolTile — authored as a normal React component, but DISCIPLINED for use as an
// isolated island: local state only (useState), no Context, no module-level
// singletons, no shared store. It talks to the outside only through props (baked
// as attributes at SSR) and a fetch (URL baked in). That discipline — plus
// bundling its own runtime — is what removes the coupling; it's the same care
// Stencil asks for, in plain React. Colours come from fleet-wide token vars.
export interface ToolProps {
  name: string;
  description: string;
  params: string; // comma-separated
  runUrl: string;
}

const T = {
  surface: "var(--color-surface, #fff)",
  border: "var(--color-border, #e4e7ec)",
  text: "var(--color-text, #1a1d23)",
  muted: "var(--color-text-muted, #667085)",
  accent: "var(--color-accent, #5b5bd6)",
  soft: "var(--color-accent-soft, #ececfb)",
  pill: "var(--radius-pill, 999px)",
};

export function ToolTile({ name, description, params, runUrl }: ToolProps) {
  const [open, setOpen] = useState(false);
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState(false);

  const list = params.split(",").map((s) => s.trim()).filter(Boolean);

  const run = async () => {
    setRunning(true);
    setError(false);
    try {
      const r = await fetch(runUrl);
      if (!r.ok) throw new Error(String(r.status));
      setResult((await r.json()).result ?? "");
    } catch {
      setError(true);
    } finally {
      setRunning(false);
    }
  };

  return (
    <article
      style={{
        boxSizing: "border-box",
        background: T.surface,
        border: `1px solid ${T.border}`,
        borderRadius: "var(--radius-md, 10px)",
        boxShadow: "0 1px 2px rgba(16,24,40,0.06), 0 1px 3px rgba(16,24,40,0.1)",
        padding: "var(--space-lg, 16px)",
        fontFamily: "var(--font-family, system-ui, sans-serif)",
        color: T.text,
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-sm, 8px)",
        maxWidth: 320,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span
          aria-hidden
          style={{
            width: 32,
            height: 32,
            borderRadius: "var(--radius-md, 10px)",
            background: T.soft,
            color: T.accent,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: 700,
          }}
        >
          {"</>"}
        </span>
        <strong style={{ fontSize: 15 }}>{name}</strong>
      </div>
      <p style={{ margin: 0, fontSize: 13, color: T.muted, lineHeight: 1.4 }}>
        {description}
      </p>
      <span
        style={{
          alignSelf: "flex-start",
          fontSize: 11,
          textTransform: "uppercase",
          letterSpacing: 0.4,
          color: T.accent,
          background: T.soft,
          borderRadius: T.pill,
          padding: "4px 8px",
        }}
      >
        MCP tool · React island (Preact)
      </span>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          style={{
            cursor: "pointer",
            font: "inherit",
            fontSize: 12,
            color: T.accent,
            background: "transparent",
            border: `1px solid ${T.accent}`,
            borderRadius: T.pill,
            padding: "6px 12px",
          }}
        >
          {open ? "Params ▴" : "Params ▾"}
        </button>
        <button
          type="button"
          onClick={run}
          disabled={running}
          style={{
            cursor: "pointer",
            font: "inherit",
            fontSize: 12,
            color: "#fff",
            background: T.accent,
            border: "none",
            borderRadius: T.pill,
            padding: "6px 12px",
          }}
        >
          {running ? "Running…" : "Run"}
        </button>
      </div>
      {open ? (
        <ul style={{ margin: "2px 0 0", paddingLeft: 18, fontSize: 12, color: T.muted }}>
          {list.map((p) => (
            <li key={p}>{p}</li>
          ))}
        </ul>
      ) : null}
      {error ? <span style={{ fontSize: 12, color: "#b42318" }}>Run failed</span> : null}
      {result ? (
        <pre
          style={{
            margin: 0,
            fontSize: 12,
            color: T.text,
            background: "var(--color-surface-muted, #f5f6f8)",
            borderRadius: 6,
            padding: 8,
            whiteSpace: "pre-wrap",
          }}
        >
          {result}
        </pre>
      ) : null}
    </article>
  );
}
