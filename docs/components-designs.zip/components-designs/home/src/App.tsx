import {
  Button,
  Badge,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
  SideNav,
  type SideNavItem,
} from "@poc/components";

/** Two-level nav: leaf links + expandable groups with second-level links. */
const nav: SideNavItem[] = [
  { label: "Home", href: "#", active: true },
  { label: "Favorites", href: "#" },
  {
    label: "Catalog",
    items: [
      { label: "Datasets", href: "#" },
      { label: "Agents", href: "#" },
      { label: "Skills", href: "#" },
      { label: "Tools", href: "#" },
    ],
  },
  {
    label: "Settings",
    items: [
      { label: "Profile", href: "#" },
      { label: "Team", href: "#" },
      { label: "Billing", href: "#" },
    ],
  },
  { label: "Help", href: "#" },
];

export function App() {
  return (
    <div className="flex min-h-screen">
      <SideNav items={nav} />

      <main className="flex-1 p-8">
        <header className="mb-6">
          <h1 className="text-2xl font-semibold">Home</h1>
          <p className="text-sm text-muted-foreground">
            Side nav + in-page tabs, all nemo-token styled.
          </p>
        </header>

        <Tabs defaultValue="favorites" className="max-w-3xl">
          <TabsList>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
            <TabsTrigger value="agents">Agents</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="favorites">
            <div className="grid gap-4 sm:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Favorited datasets</CardTitle>
                  <CardDescription>3 subscriptions</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  <Badge variant="success">Synced</Badge>
                  <Badge variant="warning">Stale</Badge>
                  <Badge variant="neutral">Archived</Badge>
                </CardContent>
                <CardFooter className="gap-2">
                  <Button size="sm">Refresh</Button>
                  <Button size="sm" variant="ghost">
                    Manage
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Pinned agents</CardTitle>
                  <CardDescription>Run with one click</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Identical look to the marketplace — one adapter, two apps.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button size="sm" variant="outline">
                    Configure
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="agents">
            <Card>
              <CardHeader>
                <CardTitle>Agent activity</CardTitle>
                <CardDescription>Last 24 hours</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                <Badge variant="success">12 runs</Badge>
                <Badge variant="info">2 new</Badge>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity">
            <p className="text-sm text-muted-foreground">No recent activity.</p>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
