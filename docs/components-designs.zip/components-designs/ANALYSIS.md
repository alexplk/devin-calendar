# Using nemo design tokens through a Tailwind (shadcn) adapter

**Question:** can we keep the nemo design system as the source of truth for token
*values*, but let developers style with Tailwind/shadcn — a stack more devs already
know — so nobody has to learn nemo's own conventions? And does Tailwind even support
theming this way?

**Short answer:** yes, and it's a small amount of work. This experiment implements
it and the production build was verified: standard Tailwind utilities compile down to
`var(--company-semantic-*)` references. Tailwind v4's CSS-first theming
(`@theme`) is essentially designed for exactly this.

---

## How it works

Tailwind v4 replaced the JS `tailwind.config` theme with a CSS `@theme` block. You
declare design tokens as CSS custom properties and Tailwind generates the matching
utilities. Because nemo already ships its tokens as CSS custom properties
(`--company-primitive-*` and `--company-semantic-*` in `global-design.css`), the two
systems meet naturally — no value duplication, no build-time codegen.

The adapter is a single `@theme inline { ... }` block in
`packages/components/src/styles/globals.css` that maps shadcn's conventional token
names onto nemo's semantic tokens:

```css
@theme inline {
  --color-background: var(--company-semantic-color-surface-page);
  --color-foreground: var(--company-semantic-color-text-primary);
  --color-primary:    var(--company-semantic-color-accent);
  --color-border:     var(--company-semantic-color-border);
  --radius-md:        var(--company-semantic-radius-md);
  --font-sans:        var(--company-primitive-font-family-sans);
  /* …full map in the file… */
}
```

The `inline` keyword is the important bit. Without it, Tailwind would emit a *copy*
of the value into its own `--color-*` variable. With `inline`, each generated utility
points at the nemo `var()` directly:

```css
.bg-primary   { background-color: var(--company-semantic-color-accent); }
.rounded-md   { border-radius:    var(--company-semantic-radius-md); }
.text-muted-foreground { color:   var(--company-semantic-color-text-muted); }
```

So a developer writes `<Button className="bg-primary rounded-md">` — pure shadcn —
and the rendered pixels come from nemo. Change a nemo token (including the
breakpoint-scoped overrides nemo defines under `@media`) and every utility that maps
to it updates at runtime. Nobody imports a nemo mixin or learns a nemo class name.

## What it took

Concretely, to make any shadcn component respect nemo tokens:

1. **Load nemo tokens** at the root (`@import "./global-design.css"` inside the
   Tailwind entry stylesheet). This stays the single source of truth for values.
2. **Write the mapping** — one `@theme inline` block, ~35 lines. This is the entire
   "adapter." It's declarative and has no runtime.
3. **Point cross-package scanning** — because the component library is a separate
   workspace package, add `@source "../ui"` so Tailwind scans its class names no
   matter which app imports the stylesheet. (Tailwind v4 auto-detects the *app's*
   files, but not linked packages.)
4. **Author components in plain Tailwind** — `Button`, `Badge`, `Card` here are
   ordinary shadcn source; none of them reference nemo directly.

That's it. Everything else (`@vitejs/plugin-react`, `@tailwindcss/vite`) is stock
Tailwind v4 wiring.

## Verified

`npm run build -w @poc/marketplace` produced a clean build, and the emitted CSS
confirms the resolution end-to-end:

| Class written by dev | Compiles to |
| --- | --- |
| `bg-primary` | `background-color: var(--company-semantic-color-accent)` |
| `text-muted-foreground` | `color: var(--company-semantic-color-text-muted)` |
| `rounded-md` | `border-radius: var(--company-semantic-radius-md)` |
| `rounded-pill` | `border-radius: var(--company-semantic-radius-pill)` |
| `border-input` | `border-color: var(--company-semantic-color-border)` |
| `bg-success-muted` / `text-success` | nemo status token pair |

Opacity modifiers still work: `bg-primary/90` compiles to
`color-mix(in oklab, var(--company-semantic-color-accent) 90%, transparent)`. This is
worth calling out because it was the classic pain point in Tailwind **v3** — there,
color utilities needed values stored as raw `H S L` channels (`0 84% 60%`) so the
`<alpha-value>` trick worked, which meant you couldn't feed hex tokens straight in.
v4's `color-mix()` approach removes that constraint, so nemo's hex tokens map cleanly.

## Gaps and things to decide

None are blockers, but they're the honest edges:

- **Font-weight tokens are unusable as-is.** nemo exports
  `--company-primitive-font-weight-medium: medium` (the *word*), which isn't a valid
  CSS `font-weight`. I did **not** map font-weight into the theme; components use
  Tailwind's `font-medium`/`font-semibold`. If you want weight driven by nemo, the
  upstream export should emit numeric weights (`500`, `600`).
- **Two parallel numeric scales.** nemo has both ratio-style
  (`--…font-line-height-100: 1.25`) and raw-unitless (`--…font-line-height-1: 16`)
  tokens. The unitless ones aren't directly usable as CSS values. For type, prefer the
  `--company-semantic-breakpoint-font-*` tokens, which carry real `rem`/`px` units. I
  left Tailwind's default `text-sm`/`text-2xl` scale in place rather than remapping the
  whole type ramp — that's a follow-up if you want type fully nemo-driven.
- **No dark mode tokens.** nemo ships one palette. shadcn expects a `.dark` variant
  block. When nemo adds dark tokens, add a `.dark { … }` override in
  `global-design.css`; the adapter and components don't change.
- **Placeholder colors.** The color primitives in `global-design.css` are the
  platform-sandbox placeholders (the note in that file flags it). Swap in the real
  palette upstream; semantic mappings and components stay untouched.
- **No semantic `destructive` in nemo.** Mapped to the red primitive for now; repoint
  to `--company-semantic-color-danger` when it exists.

## Optional guardrail

If you want to *guarantee* devs can't quietly bypass nemo by reaching for a stock
Tailwind color (`bg-red-500`, `bg-zinc-100`), you can clear Tailwind's default palette
in the theme block:

```css
@theme {
  --color-*: initial;   /* drop stock colors; only nemo-mapped names remain */
}
```

Then only the nemo-backed color names exist, and an off-system class fails loudly.
I left the defaults in for now so the experiment stays low-friction, but this is the
lever that turns "respects nemo tokens" into "can only use nemo tokens."

## Recommendation

This is a good direction and cheap to adopt. The adapter is one declarative file with
no runtime, it leaves nemo as the source of truth, and it gives you the day-to-day
ergonomics and hiring pool of Tailwind + shadcn. The realistic next steps, in order:

1. Replace placeholder color primitives with the real nemo palette.
2. Fix the upstream font-weight export to numeric, then map weights.
3. Decide whether to remap the full type ramp onto nemo semantic type tokens, or keep
   Tailwind's scale.
4. Add dark tokens upstream + a `.dark` block when needed.
5. If you want enforcement, flip on the `--color-*: initial` guardrail.

## Why Tailwind v4 (not v3)

v4's CSS-first `@theme` makes the nemo mapping a direct variable-to-variable bridge
and fixes the alpha-channel constraint described above. The tradeoff is that v4 is
newer, so some team members may know v3's `tailwind.config.js` better. The *component
authoring* experience (`className="bg-primary"`) is identical across both, so the
version choice doesn't change what developers write day to day — only where the token
mapping lives.
