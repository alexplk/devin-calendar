import React from "react";
import ReactDOM from "react-dom/client";
// The single stylesheet: Tailwind v4 + nemo tokens + the adapter.
import "@poc/components/styles.css";
import { App } from "./App";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
