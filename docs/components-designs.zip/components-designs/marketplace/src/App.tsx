import { ChevronRight } from "lucide-react";
import {
  Badge,
  SideNav,
  type SideNavItem,
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  Collapsible,
  CollapsibleTrigger,
  CollapsibleContent,
} from "@poc/components";

/** Shared nav model, rendered two ways below. */
const nav: SideNavItem[] = [
  { label: "Home", href: "#", active: true },
  { label: "Favorites", href: "#" },
  {
    label: "Catalog",
    items: [
      { label: "Datasets", href: "#" },
      { label: "Agents", href: "#" },
      { label: "Skills", href: "#" },
      { label: "Tools", href: "#" },
    ],
  },
  {
    label: "Settings",
    items: [
      { label: "Profile", href: "#" },
      { label: "Team", href: "#" },
      { label: "Billing", href: "#" },
    ],
  },
  { label: "Help", href: "#" },
];

/** Right column: the official shadcn Sidebar, embedded inline (collapsible="none"). */
function ShadcnSidebar() {
  return (
    <SidebarProvider className="min-h-0 h-full">
      <Sidebar collapsible="none" className="h-full border-r">
        <SidebarHeader className="px-3 py-3 text-sm font-semibold">
          Platform
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Main</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton isActive>Home</SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton>Favorites</SidebarMenuButton>
                </SidebarMenuItem>

                <Collapsible defaultOpen className="group/collapsible">
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton>
                        Catalog
                        <ChevronRight className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-90" />
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {["Datasets", "Agents", "Skills", "Tools"].map((l) => (
                          <SidebarMenuSubItem key={l}>
                            <SidebarMenuSubButton href="#">
                              {l}
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </SidebarMenuItem>
                </Collapsible>

                <Collapsible className="group/collapsible">
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton>
                        Settings
                        <ChevronRight className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-90" />
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {["Profile", "Team", "Billing"].map((l) => (
                          <SidebarMenuSubItem key={l}>
                            <SidebarMenuSubButton href="#">
                              {l}
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </SidebarMenuItem>
                </Collapsible>

                <SidebarMenuItem>
                  <SidebarMenuButton>Help</SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
      </Sidebar>
    </SidebarProvider>
  );
}

export function App() {
  return (
    <main className="mx-auto max-w-5xl p-8">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Sidebar comparison</h1>
        <p className="text-sm text-muted-foreground">
          Same nav, two implementations — both nemo-token styled. Pick by how
          much behavior you want to own.
        </p>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        <section>
          <div className="mb-2 flex items-center gap-2">
            <h2 className="text-sm font-medium">Custom SideNav</h2>
            <Badge variant="neutral">~80 lines</Badge>
          </div>
          <div className="h-[520px] overflow-hidden rounded-lg border">
            <SideNav items={nav} className="h-full w-full" />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Composed from Collapsible. No provider, no extra tokens. You maintain
            it.
          </p>
        </section>

        <section>
          <div className="mb-2 flex items-center gap-2">
            <h2 className="text-sm font-medium">shadcn Sidebar</h2>
            <Badge variant="info">official</Badge>
          </div>
          <div className="h-[520px] overflow-hidden rounded-lg border">
            <ShadcnSidebar />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Full system (provider, rail, mobile sheet, ⌘B, collapse-to-icon).
            ~20 parts + 8 --sidebar-* tokens mapped to nemo.
          </p>
        </section>
      </div>
    </main>
  );
}
