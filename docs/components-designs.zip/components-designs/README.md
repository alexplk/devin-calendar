# components-designs

A standalone experiment in styling **Tailwind v4 + shadcn/ui** components so that
every value resolves to a **nemo design token**. Developers write ordinary
Tailwind/shadcn (`bg-primary`, `rounded-md`, `<SidebarMenuButton>`), and the pixels
come from nemo — no nemo-specific conventions to learn. See `ANALYSIS.md` for the
rationale and the token-mapping deep dive.

This project is self-contained. It has no dependency on any other experiment or repo.

## What's in it

```
package.json                  npm workspaces root (marketplace, home, packages/*)
packages/components/          @poc/components — the shared library
  src/styles/global-design.css  nemo design tokens (--company-primitive/semantic-*)
  src/styles/globals.css        Tailwind v4 entry + the nemo→tailwind adapter
  src/lib/cn.ts                 clsx + tailwind-merge
  src/lib/use-mobile.ts         hook used by Sidebar
  src/ui/                       Button, Badge, Card, Tabs, Collapsible, SideNav,
                                Sidebar (+ Sheet, Tooltip, Separator, Skeleton, Input)
marketplace/                  Vite React SPA (port 5173) — sidebar comparison page
home/                         Vite React SPA (port 5174) — SideNav + Tabs demo
```

## What's necessary to run it

Node 18+ and npm. Nothing else is assumed on your machine.

```bash
npm install          # installs all workspaces (React, Vite, Tailwind v4, Radix, lucide)
npm run dev          # marketplace → http://localhost:5173, home → http://localhost:5174
npm run build        # production build of both apps
```

The moving parts that make it work, and why each is needed:

- **npm workspaces** (`package.json` `workspaces`) — lets the two apps consume
  `@poc/components` by name without publishing.
- **Vite v6 + `@vitejs/plugin-react`** — dev server and build for each app.
- **Tailwind v4 via `@tailwindcss/vite`** — the CSS engine. No `tailwind.config.js`;
  configuration lives in CSS (`@theme`).
- **`@poc/components`** — the shared library. Apps import one stylesheet
  (`@poc/components/styles.css`) and the components.
- **nemo tokens** (`global-design.css`) — the source of truth for values.
- **the adapter** (`globals.css`) — maps shadcn/tailwind token names onto nemo.

An app needs exactly two lines to opt in:

```ts
import "@poc/components/styles.css";
import { Button, Sidebar /* … */ } from "@poc/components";
```

## The adapter, briefly

`packages/components/src/styles/globals.css` imports Tailwind and the nemo tokens,
then a single `@theme inline { … }` block maps shadcn's conventional token names
(`--color-primary`, `--color-border`, `--radius-md`, `--color-sidebar`, …) onto
nemo's `--company-semantic-*` variables. Because the mapping is `inline`, each
generated utility references the nemo `var()` directly — change a nemo token and
every Tailwind utility that maps to it updates.

## Adding a shadcn component

In a stock shadcn project you'd run the CLI:

```bash
npx shadcn@latest add tabs        # copies the component in + installs its deps
```

The CLI needs two things this repo doesn't ship by default: network access to
`ui.shadcn.com`, and a `components.json` describing your paths/aliases. This is a
non-standard monorepo layout (the library lives in `packages/components`, imports are
relative, not `@/`), so components here are added **manually** — which is exactly what
the CLI automates. The steps, using `Tabs` as the example:

1. **Install the primitive(s)** the component is built on:
   `npm i @radix-ui/react-tabs` (check the component's `dependencies`).
2. **Add the file** to `packages/components/src/ui/tabs.tsx` (copy from the registry —
   see below).
3. **Fix imports** to this repo's layout: `@/lib/utils` → `../lib/cn`,
   `@/components/ui/x` → `./x`, hooks → `../lib/use-mobile`.
4. **Export** it from `packages/components/src/index.ts`.
5. **Map any new tokens.** If the component uses token names we haven't mapped yet
   (e.g. Sidebar's `--sidebar-*`), add them to the `@theme inline` block in
   `globals.css`, pointing at the matching nemo `--company-semantic-*` var.

Two Tailwind-v4 gotchas when pasting older ("new-york") registry source (the Sidebar
port hit both): convert the CSS-var shorthand `w-[--x]` → `w-(--x)`, and drop
`hsl(var(--token))` wrappers — nemo tokens are hex, not HSL channels, so they go in as
plain `var(--token)`.

If you'd rather use the CLI, add a `components.json` pointing at
`packages/components` and run it from a machine that can reach `ui.shadcn.com`. Ask and
I'll wire that up.

## Updating a component later

You **own** these files — there's no automatic update, which is the whole point of
shadcn (no version bumps breaking your UI). To pull upstream changes: re-fetch the
component source (CLI `add --overwrite` in a scratch project, or the registry JSON),
diff against your copy, and re-apply your nemo patches (the import rewrites + the two
v4 fixes above). Because our changes are localized (imports + a handful of class
tweaks), the diff is small.

## Where to find components (the catalog)

- **Component list & docs:** https://ui.shadcn.com/docs/components — every component
  with props, examples, and install commands.
- **Blocks / templates:** https://ui.shadcn.com/blocks — prebuilt, composed screens
  (dashboards, login pages, and several **sidebar** layouts) you can lift wholesale.
- **Raw source (what we fetched):** `https://ui.shadcn.com/r/styles/new-york/<name>.json`
  returns a component's exact source, its npm `dependencies`, and its
  `registryDependencies` (other components it needs).

Current component catalog: Accordion, Alert, Alert Dialog, Aspect Ratio, Avatar,
Badge, Breadcrumb, Button, Button Group, Calendar, Card, Carousel, Chart, Checkbox,
Collapsible, Combobox, Command, Context Menu, Data Table, Date Picker, Dialog, Drawer,
Dropdown Menu, Empty, Field, Hover Card, Input, Input Group, Input OTP, Kbd, Label,
Menubar, Native Select, Navigation Menu, Pagination, Popover, Progress, Radio Group,
Resizable, Scroll Area, Select, Separator, Sheet, Sidebar, Skeleton, Slider, Sonner
(toasts), Spinner, Switch, Table, Tabs, Textarea, Toggle, Toggle Group, Tooltip,
Typography. (There's also a newer batch aimed at AI-chat UIs — Attachment, Bubble,
Message, Message Scroller, Marker — treat those as fresher/less battle-tested.)

## Two sidebars, on purpose

`marketplace` renders a side-by-side comparison of two nav implementations, both
nemo-styled:

- **`SideNav`** (`src/ui/side-nav.tsx`) — a compact custom component (~80 lines) built
  on Collapsible. Two levels, no provider, no extra tokens. You maintain it.
- **`Sidebar`** (`src/ui/sidebar.tsx`) — the official shadcn Sidebar system (~20
  parts: provider, rail, mobile Sheet, ⌘B shortcut, collapse-to-icon). Its 8
  `--sidebar-*` tokens are mapped to nemo. More power, more surface area.

Pick by how much behavior you want to own.
