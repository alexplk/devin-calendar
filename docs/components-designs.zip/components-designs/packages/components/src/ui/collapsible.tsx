import * as CollapsiblePrimitive from "@radix-ui/react-collapsible";

/**
 * shadcn Collapsible — a thin re-export of the Radix primitive. Behaviour and
 * accessibility come from Radix; styling is applied by consumers via className.
 */
const Collapsible = CollapsiblePrimitive.Root;
const CollapsibleTrigger = CollapsiblePrimitive.CollapsibleTrigger;
const CollapsibleContent = CollapsiblePrimitive.CollapsibleContent;

export { Collapsible, CollapsibleTrigger, CollapsibleContent };
