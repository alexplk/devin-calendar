import * as React from "react";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "./collapsible";
import { cn } from "../lib/cn";

/**
 * SideNav — a composed left navigation panel (not a stock shadcn component;
 * it's assembled from the shadcn/Radix Collapsible primitive).
 *
 * Supports two levels: first-level leaf links, and first-level groups that
 * expand to reveal second-level links. Pass a nav tree via `items`.
 *
 * Styling is plain Tailwind → resolves to nemo tokens through the adapter.
 */
export interface SideNavItem {
  label: string;
  href?: string;
  icon?: React.ReactNode;
  /** Marks the current item (adds active styling + aria-current). */
  active?: boolean;
  /** Presence of `items` turns this into an expandable second-level group. */
  items?: SideNavItem[];
}

const rowBase =
  "flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

function Chevron({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 16 16"
      width="16"
      height="16"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <path
        d="M6 4l4 4-4 4"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function LeafItem({
  item,
  className,
}: {
  item: SideNavItem;
  className?: string;
}) {
  return (
    <a
      href={item.href ?? "#"}
      aria-current={item.active ? "page" : undefined}
      className={cn(
        rowBase,
        item.active && "bg-muted text-foreground",
        className
      )}
    >
      {item.icon}
      <span className="truncate">{item.label}</span>
    </a>
  );
}

function GroupItem({ item }: { item: SideNavItem }) {
  const hasActiveChild = item.items?.some((c) => c.active) ?? false;
  const [open, setOpen] = React.useState<boolean>(
    Boolean(item.active || hasActiveChild)
  );

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <CollapsibleTrigger
        className={cn(rowBase, "justify-between [&[data-state=open]>svg]:rotate-90")}
      >
        <span className="flex items-center gap-2">
          {item.icon}
          <span className="truncate">{item.label}</span>
        </span>
        <Chevron className="shrink-0 transition-transform duration-200" />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <ul className="ml-4 mt-1 space-y-1 border-l border-border pl-3">
          {item.items?.map((child) => (
            <li key={child.label}>
              <LeafItem item={child} className="py-1.5" />
            </li>
          ))}
        </ul>
      </CollapsibleContent>
    </Collapsible>
  );
}

export function SideNav({
  items,
  className,
}: {
  items: SideNavItem[];
  className?: string;
}) {
  return (
    <nav
      aria-label="Main"
      className={cn(
        "flex w-64 shrink-0 flex-col gap-1 border-r border-border bg-card p-3",
        className
      )}
    >
      {items.map((item) =>
        item.items?.length ? (
          <GroupItem key={item.label} item={item} />
        ) : (
          <LeafItem key={item.label} item={item} />
        )
      )}
    </nav>
  );
}
