import { Card } from "../../components/Card/Card";
import { Heading } from "../../components/Heading";
import { Tag } from "../../components/Tag";
import { UpdateProse } from "./UpdateProse";
import type { UpdateEntry } from "./updates.types";
import styles from "./UpdateItem.module.css";

/** One entry in the Updates feed: kind + version + date, title, tags, body. */
export function UpdateItem({ entry }: { entry: UpdateEntry }) {
  return (
    <Card>
      <div className={styles.head}>
        <div className={styles.badges}>
          <Tag tone={entry.kind === "release" ? "success" : "info"} dot>
            {entry.kind === "release" ? "Release" : "News"}
          </Tag>
          {entry.version && <span className={styles.version}>{entry.version}</span>}
        </div>
        <time className={styles.date} dateTime={entry.date}>
          {formatDate(entry.date)}
        </time>
      </div>

      <Heading level={3}>{entry.title}</Heading>

      {entry.tags?.length ? (
        <div className={styles.tags}>
          {entry.tags.map((t) => (
            <Tag key={t} tone="neutral">
              {t}
            </Tag>
          ))}
        </div>
      ) : null}

      <UpdateProse markdown={entry.body} />
    </Card>
  );
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}
