import { Stack } from "../../components/layout/Stack";
import { UpdateItem } from "./UpdateItem";
import { updates } from "./updates.mock";
import type { UpdateKind } from "./updates.types";

type UpdatesFeedProps = {
  /** when set, show only releases or only news; otherwise show everything */
  kind?: UpdateKind;
};

/**
 * The Updates feed: newest-first list of entries, optionally filtered by kind.
 * Source is the colocated mock today; swap for the file-based loader later
 * without touching this component's shape.
 */
export function UpdatesFeed({ kind }: UpdatesFeedProps) {
  const entries = updates
    .filter((e) => !kind || e.kind === kind)
    .sort((a, b) => b.date.localeCompare(a.date));

  return (
    <Stack gap={6}>
      {entries.map((entry) => (
        <UpdateItem key={entry.id} entry={entry} />
      ))}
    </Stack>
  );
}
