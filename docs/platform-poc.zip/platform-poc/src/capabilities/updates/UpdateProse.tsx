import { Fragment, type ReactNode } from "react";
import styles from "./UpdateProse.module.css";

/**
 * The seam between "content as markdown" and rendered output.
 *
 * It renders a deliberately small markdown subset — paragraphs, `- ` bullet
 * lists, inline **bold** and `code` — with no dangerouslySetInnerHTML. That is
 * enough for release notes while keeping the sandbox dependency-free.
 *
 * When content moves to real `.md`/`.mdx` files, replace the body of this
 * component with `react-markdown` (or MDX) — the call site in UpdateItem does
 * not change.
 */
type UpdateProseProps = {
  markdown: string;
};

export function UpdateProse({ markdown }: UpdateProseProps) {
  const blocks = markdown.trim().split(/\n{2,}/);

  return (
    <div className={styles.prose}>
      {blocks.map((block, i) => {
        const lines = block.split("\n");
        const isList = lines.every((l) => l.startsWith("- "));

        if (isList) {
          return (
            <ul key={i} className={styles.list}>
              {lines.map((l, j) => (
                <li key={j}>{renderInline(l.slice(2))}</li>
              ))}
            </ul>
          );
        }

        return <p key={i}>{renderInline(block.replace(/\n/g, " "))}</p>;
      })}
    </div>
  );
}

/** Inline pass: **bold** and `code`. Tokenised, so no HTML injection. */
function renderInline(text: string): ReactNode {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);

  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code key={i} className={styles.code}>
          {part.slice(1, -1)}
        </code>
      );
    }
    return <Fragment key={i}>{part}</Fragment>;
  });
}
