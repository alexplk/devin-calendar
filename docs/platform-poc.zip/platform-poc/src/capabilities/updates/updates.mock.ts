/* Updates content. Colocated stand-in for the file-based source.
 *
 * In the real app each of these becomes a `content/updates/*.md` file with the
 * fields below as frontmatter and the `body` as the markdown content. Here we
 * keep them as typed data so the sandbox runs with no markdown toolchain.
 */

import type { UpdateEntry } from "./updates.types";

export const updates: UpdateEntry[] = [
  {
    id: "nemo-0-4-0",
    kind: "release",
    title: "Nemo 0.4.0 — approval primitives",
    date: "2026-06-04",
    version: "Nemo 0.4.0",
    tags: ["Nemo", "HITL"],
    summary: "Tool-approval and human-review primitives land in Nemo.",
    body: [
      "Nemo now ships first-class **human-in-the-loop** primitives, built on the assistant-ui runtime.",
      "",
      "- `ToolApproval` — pause a run on a tool call and surface an approve / reject affordance",
      "- `HumanReview` — collect a structured decision before the agent continues",
      "- Approval state is threaded through the run so the `ApprovalTrail` can render the full history",
      "",
      "Use `**state-not-callbacks**` for approvals — wire the decision through run state rather than ad-hoc handlers. See the HITL demo cases for the recommended shape.",
    ].join("\n"),
  },
  {
    id: "agui-spike",
    kind: "news",
    title: "AG-UI integration spike underway",
    date: "2026-05-28",
    tags: ["AG-UI", "Mavric"],
    summary: "Early exploration of speaking the Agent-UI protocol from Mavric.",
    body: [
      "We've started a spike on emitting the **AG-UI** event stream from Mavric runs so Nemo can consume a protocol surface instead of a bespoke transport.",
      "",
      "Goal is to validate whether the protocol covers our HITL and tool-call cases without custom extensions. Findings will land in the research notes.",
    ].join("\n"),
  },
  {
    id: "mavric-0-3-2",
    kind: "release",
    title: "Mavric 0.3.2 — tool callback fix",
    date: "2026-05-20",
    version: "Mavric 0.3.2",
    tags: ["Mavric", "bugfix"],
    summary: "Fixes the duplicated tool-callback in the LangGraph runtime.",
    body: [
      "Resolves the tool-callback bug in the LangGraph AUI runtime where a callback could fire twice on resumed runs.",
      "",
      "If you pinned around this, you can now drop the workaround and take `Mavric 0.3.2`.",
    ].join("\n"),
  },
];
