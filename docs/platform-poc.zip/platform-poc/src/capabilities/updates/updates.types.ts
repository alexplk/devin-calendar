/* The shape of one Updates entry.
 *
 * This is deliberately the same set of fields you'd put in the YAML frontmatter
 * of a `.md`/`.mdx` file. When this moves out of the sandbox into the real app,
 * an entry becomes a file in `content/updates/`:
 *
 *   ---
 *   id: nemo-0-4-0
 *   kind: release
 *   title: Nemo 0.4.0 — approval primitives
 *   date: 2026-06-04
 *   version: Nemo 0.4.0
 *   tags: [Nemo, HITL]
 *   summary: Tool-approval and human-review primitives land in Nemo.
 *   ---
 *   <markdown body…>
 *
 * The loader (import.meta.glob + a frontmatter parser) would produce this type,
 * and only `UpdatesFeed`'s source array changes — the components stay the same.
 */

export type UpdateKind = "release" | "news";

export type UpdateEntry = {
  /** stable slug; the filename in the file-based version */
  id: string;
  kind: UpdateKind;
  title: string;
  /** ISO date, yyyy-mm-dd — sorted newest-first */
  date: string;
  /** releases only, e.g. "Nemo 0.4.0" */
  version?: string;
  tags?: string[];
  /** one-line teaser (optional; reserved for a future collapsed/feed view) */
  summary?: string;
  /** markdown body — see UpdateProse for the supported subset */
  body: string;
};
