import type { Agent } from "./agent.mock";
import styles from "./ApprovalTrail.module.css";

/** Chronological governance trail: each entry is date (left) + detail (right). */
export function ApprovalTrail({ entries }: { entries: Agent["approvals"] }) {
  return (
    <ol className={styles.trail}>
      {entries.map((entry, i) => (
        <li key={i} className={styles.entry}>
          <time className={styles.date}>{entry.date}</time>
          <div className={styles.detail}>
            <div className={styles.role}>{entry.role}</div>
            <div className={styles.note}>{entry.note}</div>
          </div>
        </li>
      ))}
    </ol>
  );
}
