import { Panel } from "../../components/Panel";
import { Section } from "../../components/Section/Section";
import { PropertyGrid } from "../../components/PropertyGrid/PropertyGrid";
import type { Agent } from "./agent.mock";

/** How the agent binds to business process + ontology. */
export function ProcessBindingsPanel({
  bindings,
}: {
  bindings: Agent["bindings"];
}) {
  return (
    <Panel>
      <Section title="Process &amp; ontology bindings">
        <PropertyGrid layout="inline" items={bindings} />
      </Section>
    </Panel>
  );
}
