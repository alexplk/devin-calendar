import u from "../../styles/utils.module.css";
import { Columns } from "../../components/layout/Columns";
import { Stack } from "../../components/layout/Stack";
import { Panel } from "../../components/Panel";
import { Button } from "../../components/Button";
import { Section } from "../../components/Section/Section";
import { PropertyGrid } from "../../components/PropertyGrid/PropertyGrid";
import { ExampleOutput } from "./ExampleOutput";
import { ApprovalTrail } from "./ApprovalTrail";
import { OwnershipPanel } from "./OwnershipPanel";
import { ProcessBindingsPanel } from "./ProcessBindingsPanel";
import { SubscribeUpdates } from "./SubscribeUpdates";
import type { Agent } from "./agent.mock";

/** Summary tab — what the agent does + evidence, with an ownership sidebar. */
export function AgentSummary({ agent }: { agent: Agent }) {
  return (
    <Columns
      asideWidth="320px"
      main={
        <Stack gap={7}>
          <Panel>
            <Section title="What this agent does">
              <p>{agent.whatItDoes}</p>
              
              <hr/>

              <PropertyGrid layout="stacked" items={agent.stats} />
            </Section>
          </Panel>

          <Panel>
            <Section
              title="Example output"
              action={<a className={u.mutedLink} href="#">Another sample</a>}
            >
              <ExampleOutput example={agent.example} />
            </Section>
          </Panel>

          <Panel>
            <Section
              title="Approval trail"
              action={<Button size="small">Open in governance</Button>}
            >
              <ApprovalTrail entries={agent.approvals} />
            </Section>
          </Panel>
        </Stack>
      }
      aside={
        <Stack gap={7}>
          <OwnershipPanel ownership={agent.ownership} />
          <ProcessBindingsPanel bindings={agent.bindings} />
          <SubscribeUpdates subscriptions={agent.subscriptions} />
        </Stack>
      }
    />
  );
}
