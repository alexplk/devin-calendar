import { PageHeader } from "../../components/PageHeader/PageHeader";
import { Tag } from "../../components/Tag";
import { StatusBadge } from "../../components/StatusBadge/StatusBadge";
import { Button } from "../../components/Button";
import type { Agent } from "./agent.mock";

/** Agent identity header: name, lifecycle + category chips, primary actions. */
export function AgentPageHeader({ agent }: { agent: Agent }) {
  return (
    <PageHeader
      breadcrumb={agent.breadcrumb}
      title={agent.name}
      description={agent.description}
      tags={
        <>
          <Tag tone="accent">{agent.kind}</Tag>
          <StatusBadge status={agent.status} />
          {agent.chips.map((chip) => (
            <Tag key={chip} tone="neutral">
              {chip}
            </Tag>
          ))}
        </>
      }
      actions={
        <>
          <Button variant="secondary">Favourite</Button>
          <Button variant="primary">Try this agent</Button>
        </>
      }
    />
  );
}
