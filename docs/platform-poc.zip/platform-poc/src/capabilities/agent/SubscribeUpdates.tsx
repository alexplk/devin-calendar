import u from "../../styles/utils.module.css";
import { useState } from "react";
import { Panel } from "../../components/Panel";
import { Section } from "../../components/Section/Section";
import { Toggle } from "../../components/Toggle";
import type { Agent } from "./agent.mock";
import styles from "./SubscribeUpdates.module.css";

/** Notification preferences for this agent. */
export function SubscribeUpdates({
  subscriptions,
}: {
  subscriptions: Agent["subscriptions"];
}) {
  const [state, setState] = useState(() =>
    subscriptions.map((s) => s.on),
  );

  return (
    <Panel>
      <Section title="Subscribe to updates">
        <ul className={styles.list}>
          {subscriptions.map((sub, i) => (
            <li key={sub.label} className={styles.item}>
              <div className={styles.text}>
                <div className={styles.label}>{sub.label}</div>
                <div className={u.caption}>{sub.description}</div>
              </div>
              <Toggle
                checked={state[i]}
                label={sub.label}
                onChange={(next) =>
                  setState((prev) =>
                    prev.map((v, j) => (j === i ? next : v)),
                  )
                }
              />
            </li>
          ))}
        </ul>
      </Section>
    </Panel>
  );
}
