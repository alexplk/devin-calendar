import u from "../../styles/utils.module.css";
import { Tag } from "../../components/Tag";
import type { Agent } from "./agent.mock";
import styles from "./ExampleOutput.module.css";

/** A sample run of the agent: context, sub-agents involved, drafted output. */
export function ExampleOutput({ example }: { example: Agent["example"] }) {
  return (
    <div className={styles.wrap}>
      <hr />

      <p className={styles.context}>{example.context}</p>
      
      <div className={styles.tags}>
        {example.tags.map((t) => (
          <Tag
            key={t}
            tone={t.toLowerCase().includes("exception") ? "warning" : "neutral"}
          >
            {t}
          </Tag>
        ))}
      </div>
      <hr />

      <p className={styles.body}>{example.body}</p>
      <p className={u.caption}>{example.footer}</p>
    </div>
  );
}
