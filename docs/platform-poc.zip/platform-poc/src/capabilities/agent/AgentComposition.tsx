import { Stack } from "../../components/layout/Stack";
import { Panel } from "../../components/Panel";
import { Button } from "../../components/Button";
import { Section } from "../../components/Section/Section";
import { Placeholder } from "../../components/Placeholder";
import { Tabs } from "../../components/Tabs/Tabs";
import { AssetList } from "../asset/AssetList";
import type { Agent } from "./agent.mock";

/** Composition tab — the components that make up the agent. */
export function AgentComposition({ agent }: { agent: Agent }) {
  const { subAgents, skills, tools } = agent.composition;
  const total = subAgents.length + skills.length + tools.length;

  return (
    <Stack gap={8}>
      <Panel>
        <Section
          title="Agent composition"
          description={`What's inside · ${total} components · All approved`}
          action={<Button size="small">Open in YAML</Button>}
        >
          <Placeholder label="Composition diagram" height={260} />
        </Section>
      </Panel>

      <Tabs
        tabs={[
          {
            label: `Sub-agents (${subAgents.length})`,
            content: <AssetList items={subAgents} />,
          },
          {
            label: `Skills (${skills.length})`,
            content: <AssetList items={skills} />,
          },
          {
            label: `Tools (${tools.length})`,
            content: <AssetList items={tools} />,
          },
          { label: "Approved", content: <Placeholder label="Approvals view" /> },
        ]}
      />
    </Stack>
  );
}
