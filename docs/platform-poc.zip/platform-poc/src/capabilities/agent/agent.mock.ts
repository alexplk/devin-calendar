/* Mock data for the agent detail page. Colocated with the agent capabilities
 * so it stays out of the component logic. Stand-in only. */

export type AssetRow = {
  glyph: string;
  eyebrow: string;
  title: string;
  meta: string;
  description: string;
  status: string;
  categories: string[];
};

export const agent = {
  id: "pl-variance-commentary",
  name: "P&L Variance & Commentary Agent — Group Finance",
  breadcrumb: "Home / Agents / Compare 2 agent candidates / P&L Variance & Commentary v2.3",
  kind: "Agent",
  status: "Production",
  chips: ["Reuse champion — Group Finance", "Daily Close — P&L"],
  description:
    "Drafts a daily P&L variance commentary from approved Group P&L slices, with a named-driver split, anomaly flags, and a hand-off to supervisor or senior stakeholder in your tone of voice.",

  whatItDoes:
    "Each weekday, this agent pulls the approved P&L slice for your scope, reconciles it against the prior day, and produces a driver-split column (e.g. price vs FX vs rate). It writes a 4–6 line variance narrative in your saved tone of voice, flags any driver more than 2σ from its trailing average, and hands the result to Outlook as a draft addressed to your line manager. Read-only contract — it never modifies a source.",

  stats: [
    { label: "Runs · 30d", value: "312" },
    { label: "Seats using", value: "12" },
    { label: "Avg. response time", value: "1.4s" },
    { label: "Avg cost / run", value: "0.21 USD" },
    { label: "Re-use score", value: "82%" },
  ],

  example: {
    title: "P&L Exception Triggered",
    context: "Equity Exotics — T0 vs T-1 · Trading Activity (250M)",
    tags: ["P&L Adjustment Sub Agent", "P&L Commentary Sub Agent", "Exception detected"],
    body:
      "EUR redemption: Notional 250M with cash consideration of 125M3 while commentary: EUR redemption ISIN XXXX123A6 with notional 250m. Offset against cash consideration. Go ahead with adjustment and suggested commentary — then auto-submit for sign-off?",
    footer: "Drafted by P&L Variance & Commentary · 4 sources cited · review before sending",
  },

  approvals: [
    {
      date: "04 Apr 2026",
      role: "Group Finance Data Owner · Christina Schmidt",
      note: "Production approval — data scope verified",
    },
    {
      date: "11 Apr 2026",
      role: "Model Risk · Sarah Tewel",
      note: "Risk tier 2 — low confidence threshold set to 8% with auto-escalation",
    },
    {
      date: "14 Apr 2026",
      role: "Software inventory · SI-FIN-04217",
      note: "Agent and skills registered with central inventory — with group-wide visibility",
    },
  ],

  ownership: [
    { label: "Owner", value: "Alexander Preston" },
    { label: "Stream delegate", value: "Natalie Merchant" },
    { label: "Maintainers", value: "GF-Technology — Data & AI Stream" },
    { label: "Software inventory", value: "SI-FIN-04217" },
    { label: "Risk tier", value: "2 — Medium impact AI" },
    { label: "Latest service", value: "v2.3 · 02 Apr 2026" },
  ],

  bindings: [
    { label: "Business process", value: "Daily Close — P&L and Balance Sheet" },
    { label: "Domain concept", value: "P&L Driver Analysis (Group Finance)" },
    { label: "Domain model", value: "GF · Variance & Commentary v2.3" },
  ],

  subscriptions: [
    {
      label: "New versions",
      description: "≤ 2 minor starts 24 May 2026",
      on: true,
    },
    {
      label: "Incidents / SLA breaches",
      description: "Significant events, missed or rare beats",
      on: true,
    },
    {
      label: "Approval changes",
      description: "Tone owner, Model risk",
      on: false,
    },
  ],

  composition: {
    subAgents: [
      {
        glyph: "DQ",
        eyebrow: "Sub-agent · Skill",
        title: "Data Quality Pre-Check",
        meta: "Group Finance Tech · Data & Analytics · Gateway",
        description:
          "Runs the CDM rules against the P&L slice before the variance is computed. Aborts the run if completeness or freshness fall below thresholds.",
        status: "Production",
        categories: ["Data Quality", "Gateway"],
      },
      {
        glyph: "AS",
        eyebrow: "Sub-agent · Workflow",
        title: "Approval & Sign-off",
        meta: "Group Finance Tech · Data & Analytics · Workflow",
        description:
          "Routes the draft export to your supervisor or hands off to the next person in the workflow for approval and sign-off.",
        status: "Production",
        categories: ["Reporting", "Sign-off", "Task orchestration"],
      },
    ],
    skills: [
      {
        glyph: "VD",
        eyebrow: "Skill",
        title: "P&L Variance Detection",
        meta: "Group Finance Tech · Daily P&L",
        description:
          "Decomposes today's P&L against the prior day at the named-driver level, with netbook numerals and a CDS side output.",
        status: "Production",
        categories: ["Daily P&L", "Variance Detection"],
      },
      {
        glyph: "DD",
        eyebrow: "Skill",
        title: "Driver Decomposition",
        meta: "Group Finance Tech",
        description:
          "Splits a variance into named drivers (volume, price, FX, rate). Bedding block reused by 42 other agents.",
        status: "Production",
        categories: ["Re-use champion", "Driver Analysis"],
      },
      {
        glyph: "CG",
        eyebrow: "Skill",
        title: "Commentary Generator",
        meta: "Group Finance Tech · Reporting",
        description:
          "Drafts variance narrative in a controlled voice. Will write about the figures the calculation and exception detector produced, but will not invent new ones.",
        status: "Production",
        categories: ["Commentary", "Narrative"],
      },
    ],
    tools: [
      {
        glyph: "aF",
        eyebrow: "Tool",
        title: "ampliFi P&L Reporting",
        meta: "Group Finance Technology · Reporting",
        description:
          "Takes desk and sub-desk based P&L reports, with an comment monitoring and signed-off commentary; includes aggregates for Legal Entity, Region, BS and Group views for final analysis.",
        status: "Production",
        categories: ["Group Controlling", "Income statement", "Daily P&L"],
      },
    ] satisfies AssetRow[],
  },
};

export type Agent = typeof agent;
