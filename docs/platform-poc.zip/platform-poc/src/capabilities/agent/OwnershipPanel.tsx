import u from "../../styles/utils.module.css";
import { Panel } from "../../components/Panel";
import { Section } from "../../components/Section/Section";
import { PropertyGrid } from "../../components/PropertyGrid/PropertyGrid";
import { IconBox } from "../../components/IconBox";
import { Row } from "../../components/layout/Row";
import { Stack } from "../../components/layout/Stack";
import type { Agent } from "./agent.mock";
import styles from "./OwnershipPanel.module.css";

/** Who owns and maintains the agent. */
export function OwnershipPanel({ ownership }: { ownership: Agent["ownership"] }) {
  const [owner, ...rest] = ownership;
  return (
    <Panel>
      <Section title="Ownership">
        <Stack gap={6}>
          <Row gap={5}>
            <IconBox glyph="AP" size="large" shape="circle" />
            <div>
              <div className={styles.name}>{owner.value}</div>
              <div className={u.caption}>Group Finance Tech · Data &amp; AI</div>
            </div>
          </Row>
          <PropertyGrid layout="inline" items={rest} />
        </Stack>
      </Section>
    </Panel>
  );
}
