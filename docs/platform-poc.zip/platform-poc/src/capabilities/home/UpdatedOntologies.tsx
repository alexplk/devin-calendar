import u from "../../styles/utils.module.css";
import { Section } from "../../components/Section/Section";
import { Card } from "../../components/Card/Card";
import { ontologies } from "./home.mock";
import styles from "./UpdatedOntologies.module.css";

/** Recently updated domain ontologies, as cards. */
export function UpdatedOntologies() {
  return (
    <Section
      title="Updated ontologies"
      action={<a className={u.mutedLink} href="#">View all</a>}
    >
      <div className={styles.grid}>
        {ontologies.map((o) => (
          <Card key={o.title}>
            <div className={u.caption}>{o.scheme}</div>
            <div className={styles.title}>{o.title}</div>
            <div className={styles.concept}>{o.concept}</div>
            <div className={u.caption}>{o.bindings}</div>
          </Card>
        ))}
      </div>
    </Section>
  );
}
