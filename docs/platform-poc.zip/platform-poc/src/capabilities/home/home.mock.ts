/* Mock data for the home dashboard. Colocated, stand-in only. */

export const greeting = {
  name: "Alex",
  context: "Group Finance · Investment Bank",
  prompts: [
    "Show latest variance across my agents",
    "Why did Close Narrator drift overnight?",
    "Show my team's usage over the last week",
  ],
};

export type RecommendedAgent = {
  id: string;
  name: string;
  kind: string;
  status: string;
  description: string;
  stats: { label: string; value: string }[];
};

export const recommendedAgents: RecommendedAgent[] = [
  {
    id: "close-narrator",
    name: "Close Narrator — Daily Balance Sheet",
    kind: "Agent",
    status: "Beta",
    description:
      "Drafts a daily close narrative based on approved variances and drivers for the daily close. Currently in Beta — not yet production.",
    stats: [
      { label: "Re-use score", value: "76%" },
      { label: "Runs · 30d", value: "102" },
      { label: "Seats", value: "1.2k" },
    ],
  },
  {
    id: "toft-exception",
    name: "TOFT Exception Watcher — P&L",
    kind: "Agent",
    status: "Production",
    description:
      "Scans the flash P&L at end of day, then runs a T1 recon to identify any exceptions. Tasks are then auto-escalated to controllers.",
    stats: [
      { label: "Re-use score", value: "82%" },
      { label: "Runs · 30d", value: "28" },
      { label: "Seats", value: "1.4k" },
    ],
  },
  {
    id: "pl-variance-commentary",
    name: "P&L Variance & Commentary",
    kind: "Agent",
    status: "Production",
    description:
      "The agent drafts a daily P&L variance commentary from approved P&L slices, with a named-driver split, anomaly flags, and a hand-off.",
    stats: [
      { label: "Re-use score", value: "82%" },
      { label: "Runs · 30d", value: "312" },
      { label: "Seats", value: "1.8k" },
    ],
  },
];

export type ObservabilityRow = {
  agent: string;
  scope: string;
  actsOn: string;
  status: string;
  runs: string;
};

export const observability: ObservabilityRow[] = [
  {
    agent: "BS Driver Analysis",
    scope: "Group Risk",
    actsOn: "balance_sheet_summary",
    status: "Production",
    runs: "312",
  },
  {
    agent: "Daily P&L Recon",
    scope: "Group Finance",
    actsOn: "daily_pnl_eq_derive",
    status: "Production",
    runs: "56",
  },
  {
    agent: "Capital Adequacy Helper",
    scope: "Treasury",
    actsOn: "london_branch_pos",
    status: "Pending review",
    runs: "18",
  },
  {
    agent: "Credit Loss Expense Analysis",
    scope: "Group Finance",
    actsOn: "balance_sheet_summary",
    status: "Production",
    runs: "590",
  },
  {
    agent: "Month-End P&L Validation",
    scope: "Group Finance",
    actsOn: "daily_pnl_eq_derive",
    status: "Production",
    runs: "56",
  },
];

export type Ontology = {
  scheme: string;
  title: string;
  concept: string;
  bindings: string;
};

export const ontologies: Ontology[] = [
  {
    scheme: "Scheme / Group Finance",
    title: "Group Income Statement",
    concept: "Credit Loss Expense",
    bindings: "Bindings: 6 data products · 11 days ago",
  },
  {
    scheme: "Scheme / Investment Bank",
    title: "Investment Bank",
    concept: "Exchange Traded Security",
    bindings: "Bindings: 12 data products · 19 days ago",
  },
  {
    scheme: "Scheme / Wealth Management",
    title: "WM Balance Sheet",
    concept: "Net New Money",
    bindings: "Bindings: 4 data products · 14 days ago",
  },
];
