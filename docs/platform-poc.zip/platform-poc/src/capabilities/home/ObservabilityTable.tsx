import u from "../../styles/utils.module.css";
import { Section } from "../../components/Section/Section";
import { Panel } from "../../components/Panel";
import { Button } from "../../components/Button";
import { StatusBadge } from "../../components/StatusBadge/StatusBadge";
import { observability } from "./home.mock";
import styles from "./ObservabilityTable.module.css";

/** Agents currently acting on the user's data. */
export function ObservabilityTable() {
  return (
    <Section
      title="Observability — agents acting on my data"
      action={<a className={u.mutedLink} href="#">View all telemetry</a>}
    >
      <Panel >
        <table className={styles.table}>
          <thead>
            <tr>
              <th>Agent / skill</th>
              <th>Acts on</th>
              <th>Status</th>
              <th className={styles.num}>Runs · 24h</th>
              <th aria-label="actions" />
            </tr>
          </thead>
          <tbody>
            {observability.map((row) => (
              <tr key={row.agent}>
                <td>
                  <div className={styles.agent}>{row.agent}</div>
                  <div className={u.caption}>{row.scope}</div>
                </td>
                <td className={styles.mono}>{row.actsOn}</td>
                <td>
                  <StatusBadge status={row.status} />
                </td>
                <td className={styles.num}>{row.runs}</td>
                <td className={styles.num}>
                  <Button size="small">View detail</Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Panel>
    </Section>
  );
}
