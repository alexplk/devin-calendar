import u from "../../styles/utils.module.css";
import { Link } from "react-router-dom";
import { Section } from "../../components/Section/Section";
import { Card } from "../../components/Card/Card";
import { Tag } from "../../components/Tag";
import { StatusBadge } from "../../components/StatusBadge/StatusBadge";
import { PropertyGrid } from "../../components/PropertyGrid/PropertyGrid";
import { Row } from "../../components/layout/Row";
import { recommendedAgents } from "./home.mock";
import styles from "./RecommendedAgents.module.css";

/** Agents recommended for this user, as a row of cards. */
export function RecommendedAgents() {
  return (
    <Section
      title="Recommended agents"
      action={<Link className={u.mutedLink} to="/agents">View all agents</Link>}
    >
      <div className={styles.grid}>
        {recommendedAgents.map((agent) => (
          <Card key={agent.id} interactive>
            <Row gap={3}>
              <Tag tone="accent">{agent.kind}</Tag>
              <StatusBadge status={agent.status} />
            </Row>
            <Link to={`/agents/${agent.id}`} className={styles.title}>
              {agent.name}
            </Link>
            <p className={styles.description}>{agent.description}</p>
            <PropertyGrid layout="stacked" items={agent.stats} columns={3} />
          </Card>
        ))}
      </div>
    </Section>
  );
}
