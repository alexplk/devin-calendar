import u from "../../styles/utils.module.css";
import { Heading } from "../../components/Heading";
import { Button } from "../../components/Button";
import { Stack } from "../../components/layout/Stack";
import { greeting } from "./home.mock";
import styles from "./PromptLauncher.module.css";

/** The home hero: greeting + ask-anything launcher + suggested prompts. */
export function PromptLauncher() {
  return (
    <Stack gap={6}>
      <div className={u.caption}>
        Good morning, {greeting.name} · {greeting.context}
      </div>
      <Heading level={1}>What would you like to do today?</Heading>
      <p className={styles.sub}>
        Use an AI-assistant search to find the agents, tools or data you&apos;re
        looking for, or browse the full inventory in the left-hand menu.
      </p>

      <div className={styles.launcher}>
        <input
          className={styles.input}
          placeholder="Ask anything, or describe what you need to do…"
          aria-label="Ask anything"
        />
        <Button variant="secondary">Browse marketplace</Button>
        <Button variant="primary">Ask</Button>
      </div>

      <div className={styles.prompts}>
        {greeting.prompts.map((p) => (
          <button key={p} className={styles.prompt}>
            {p}
          </button>
        ))}
      </div>
    </Stack>
  );
}
