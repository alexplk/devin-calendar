import { ListRow } from "../../components/ListRow/ListRow";
import { StatusBadge } from "../../components/StatusBadge/StatusBadge";
import { Tag } from "../../components/Tag";
import { Button } from "../../components/Button";
import type { AssetRow } from "../agent/agent.mock";

/** A list of inventory assets (agents, skills, tools) rendered as rows. */
export function AssetList({ items }: { items: AssetRow[] }) {
  return (
    <div>
      {items.map((item) => (
        <ListRow
          key={item.title}
          glyph={item.glyph}
          eyebrow={item.eyebrow}
          title={item.title}
          meta={item.meta}
          description={item.description}
          tags={
            <>
              <StatusBadge status={item.status} />
              {item.categories.map((c) => (
                <Tag key={c} tone="neutral">
                  {c}
                </Tag>
              ))}
            </>
          }
          action={<Button size="small">Open</Button>}
        />
      ))}
    </div>
  );
}
