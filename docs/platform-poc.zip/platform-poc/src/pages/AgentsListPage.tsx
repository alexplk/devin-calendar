import { Page } from "../components/layout/Page";
import { Stack } from "../components/layout/Stack";
import { Panel } from "../components/Panel";
import { PageHeader } from "../components/PageHeader/PageHeader";
import { AssetList } from "../capabilities/asset/AssetList";
import { agent } from "../capabilities/agent/agent.mock";

/**
 * A list-of-assets page (not an asset itself). Reuses the same AssetList the
 * composition tab uses — here populated from the agent's components as stand-in
 * inventory.
 */
export function AgentsListPage() {
  const items = [
    ...agent.composition.subAgents,
    ...agent.composition.skills,
    ...agent.composition.tools,
  ];

  return (
    <Page>
      <Stack gap={8}>
        <PageHeader
          breadcrumb="Home / Agents"
          title="Agents"
          description="Browse the agent inventory available to Group Finance · Investment Bank."
        />
        <Panel>
          <AssetList items={items} />
        </Panel>
      </Stack>
    </Page>
  );
}
