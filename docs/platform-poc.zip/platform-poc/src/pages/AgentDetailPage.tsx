import { Page } from "../components/layout/Page";
import { Stack } from "../components/layout/Stack";
import { Tabs } from "../components/Tabs/Tabs";
import { Placeholder } from "../components/Placeholder";
import { AgentPageHeader } from "../capabilities/agent/AgentPageHeader";
import { AgentSummary } from "../capabilities/agent/AgentSummary";
import { AgentComposition } from "../capabilities/agent/AgentComposition";
import { agent } from "../capabilities/agent/agent.mock";

/** Agent asset detail. Reads as: header, then the agent's tabbed facets. */
export function AgentDetailPage() {
  return (
    <Page>
      <Stack gap={9}>
        <AgentPageHeader agent={agent} />
        <Tabs
          defaultIndex={0}
          tabs={[
            { label: "Summary", content: <AgentSummary agent={agent} /> },
            { label: "Composition", content: <AgentComposition agent={agent} /> },
            { label: "Data Sources", content: <Placeholder label="Data Sources tab" /> },
            { label: "Operations", content: <Placeholder label="Operations tab" /> },
            { label: "Access", content: <Placeholder label="Access tab" /> },
            { label: "Governance", content: <Placeholder label="Governance tab" /> },
            { label: "Telemetry", content: <Placeholder label="Telemetry tab" /> },
          ]}
        />
      </Stack>
    </Page>
  );
}
