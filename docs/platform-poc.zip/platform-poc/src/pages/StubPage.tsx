import { useLocation } from "react-router-dom";
import { Page } from "../components/layout/Page";
import { Stack } from "../components/layout/Stack";
import { PageHeader } from "../components/PageHeader/PageHeader";
import { Placeholder } from "../components/Placeholder";

/** Stand-in for nav destinations not built in this sandbox. */
export function StubPage() {
  const { pathname } = useLocation();
  return (
    <Page>
      <Stack gap={8}>
        <PageHeader title={pathname} breadcrumb="Home" />
        <Placeholder label={`Page: ${pathname}`} height={320} />
      </Stack>
    </Page>
  );
}
