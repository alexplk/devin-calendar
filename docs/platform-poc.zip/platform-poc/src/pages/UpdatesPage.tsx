import { Page } from "../components/layout/Page";
import { Stack } from "../components/layout/Stack";
import { PageHeader } from "../components/PageHeader/PageHeader";
import { Tabs } from "../components/Tabs/Tabs";
import { UpdatesFeed } from "../capabilities/updates/UpdatesFeed";

/** News and release notes for the platform, Mavric and Nemo. */
export function UpdatesPage() {
  return (
    <Page>
      <Stack gap={8}>
        <PageHeader
          title="Updates"
          description="News and release notes for the platform, Mavric and Nemo."
        />
        <Tabs
          tabs={[
            { label: "All", content: <UpdatesFeed /> },
            { label: "Releases", content: <UpdatesFeed kind="release" /> },
            { label: "News", content: <UpdatesFeed kind="news" /> },
          ]}
        />
      </Stack>
    </Page>
  );
}
