import { Page } from "../components/layout/Page";
import { Stack } from "../components/layout/Stack";
import { PromptLauncher } from "../capabilities/home/PromptLauncher";
import { RecommendedAgents } from "../capabilities/home/RecommendedAgents";
import { ObservabilityTable } from "../capabilities/home/ObservabilityTable";
import { UpdatedOntologies } from "../capabilities/home/UpdatedOntologies";

export function HomePage() {
  return (
    <Page>
      <Stack gap={12}>
        <PromptLauncher />
        <RecommendedAgents />
        <ObservabilityTable />
        <UpdatedOntologies />
      </Stack>
    </Page>
  );
}
