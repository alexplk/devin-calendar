import { Routes, Route } from "react-router-dom";
import { AppShell } from "./components/AppShell/AppShell";
import { HomePage } from "./pages/HomePage";
import { AgentsListPage } from "./pages/AgentsListPage";
import { AgentDetailPage } from "./pages/AgentDetailPage";
import { UpdatesPage } from "./pages/UpdatesPage";
import { StubPage } from "./pages/StubPage";

/**
 * Route table. Top-level pages live in src/pages; the shell (masthead + nav)
 * is the layout route wrapping all of them.
 */
export default function App() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<HomePage />} />
        <Route path="/agents" element={<AgentsListPage />} />
        <Route path="/agents/:id" element={<AgentDetailPage />} />
        <Route path="/updates" element={<UpdatesPage />} />
        <Route path="*" element={<StubPage />} />
      </Route>
    </Routes>
  );
}
