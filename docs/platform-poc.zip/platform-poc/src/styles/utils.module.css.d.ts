/* Typed keys for utils.module.css — gives autocomplete and catches typos at
 * the call site (u.captoin -> compile error). Hand-maintained for now; keep in
 * sync with utils.module.css, or switch to generated declarations (e.g.
 * typed-css-modules / vite-plugin-sass-dts) when the set grows. */
declare const styles: {
  readonly mutedLink: string;
  readonly caption: string;
};
export default styles;
