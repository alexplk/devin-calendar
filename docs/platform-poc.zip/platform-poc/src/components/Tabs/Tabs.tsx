import { useState, type ReactNode } from "react";
import styles from "./Tabs.module.css";

export type TabItem = {
  label: string;
  content: ReactNode;
};

type TabsProps = {
  tabs: TabItem[];
  defaultIndex?: number;
};

/**
 * Draft tab control. Items-based so a page can declare its tabs as data:
 *   <Tabs tabs={[{ label, content }, …]} />
 * Owns the tablist DOM + selection state internally.
 */
export function Tabs({ tabs, defaultIndex = 0 }: TabsProps) {
  const [active, setActive] = useState(defaultIndex);

  return (
    <div className={styles.tabs}>
      <div className={styles.tablist} role="tablist">
        {tabs.map((tab, i) => (
          <button
            key={tab.label}
            role="tab"
            aria-selected={i === active}
            className={[styles.tab, i === active ? styles.active : ""].join(" ")}
            onClick={() => setActive(i)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div role="tabpanel" className={styles.panel}>
        {tabs[active]?.content}
      </div>
    </div>
  );
}
