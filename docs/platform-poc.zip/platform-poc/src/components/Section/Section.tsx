import type { ReactNode } from "react";
import { Heading } from "../../components/Heading";
import styles from "./Section.module.css";

type SectionProps = {
  title?: string;
  /** muted line under the title, in the same column (subtitle / description) */
  description?: ReactNode;
  /** right-aligned action, e.g. a "View all" link or button */
  action?: ReactNode;
  children: ReactNode;
  level?: 2 | 3 | 4;
};

/** A titled block of content with an optional description and trailing action. */
export function Section({
  title,
  description,
  action,
  children,
  level = 3,
}: SectionProps) {
  const hasHead = title || description || action;
  return (
    <section className={styles.section}>
      {hasHead && (
        <div className={styles.head}>
          {(title || description) && (
            <div className={styles.heading}>
              {title && <Heading level={level}>{title}</Heading>}
              {description && <p className={styles.description}>{description}</p>}
            </div>
          )}
          {action && <div className={styles.action}>{action}</div>}
        </div>
      )}
      {children}
    </section>
  );
}
