import { useId } from "react";
import styles from "./Toggle.module.css";

type ToggleProps = {
  checked: boolean;
  onChange?: (next: boolean) => void;
  label?: string;
};

/** Switch control. Wraps a native checkbox to keep behaviour/a11y correct. */
export function Toggle({ checked, onChange, label }: ToggleProps) {
  const id = useId();
  return (
    <span className={styles.wrap}>
      <input
        id={id}
        type="checkbox"
        role="switch"
        className={styles.input}
        checked={checked}
        onChange={(e) => onChange?.(e.target.checked)}
        aria-label={label}
      />
      <span className={styles.track} aria-hidden="true">
        <span className={styles.thumb} />
      </span>
    </span>
  );
}
