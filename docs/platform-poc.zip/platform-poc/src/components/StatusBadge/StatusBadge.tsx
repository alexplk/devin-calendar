import { Tag } from "../../components/Tag";

type StatusBadgeProps = {
  status: string;
};

/** Maps a lifecycle status string to a toned Tag. Domain vocabulary in, chrome out. */
export function StatusBadge({ status }: StatusBadgeProps) {
  const key = status.toLowerCase();
  const tone =
    key === "production"
      ? "success"
      : key.includes("pending") || key.includes("review")
        ? "warning"
        : key === "beta" || key === "draft"
          ? "info"
          : "neutral";

  return (
    <Tag tone={tone} dot>
      {status}
    </Tag>
  );
}
