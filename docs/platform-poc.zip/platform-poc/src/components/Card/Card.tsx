import type { ReactNode } from "react";
import styles from "./Card.module.css";

type CardProps = {
  children: ReactNode;
  /** adds hover affordance for clickable cards */
  interactive?: boolean;
  onClick?: () => void;
};

/** Bordered content card. Interactive variant lifts on hover. */
export function Card({ children, interactive = false, onClick }: CardProps) {
  const cls = [styles.card, interactive ? styles.interactive : ""]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={cls} onClick={onClick}>
      {children}
    </div>
  );
}
