import type { ReactNode } from "react";
import styles from "./Tag.module.css";

type TagProps = {
  children: ReactNode;
  tone?: "neutral" | "accent" | "success" | "warning" | "info";
  /** show a leading dot (used for status-style tags) */
  dot?: boolean;
};

/** Small pill label. Structure (dot + text) lives inside, so it's a component. */
export function Tag({ children, tone = "neutral", dot = false }: TagProps) {
  return (
    <span className={[styles.tag, styles[tone]].join(" ")}>
      {dot && <span className={styles.dot} aria-hidden="true" />}
      {children}
    </span>
  );
}
