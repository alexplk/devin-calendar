import type { CSSProperties, ReactNode } from "react";
import styles from "./Panel.module.css";

type PanelProps = {
  children: ReactNode;
  /** subtle = tinted background instead of white */
  tone?: "default" | "subtle";
  /** remove inner padding (for panels that manage their own internal layout) */
  flush?: boolean;
  style?: CSSProperties;
};

/** A bordered surface box — the "little panel with a border". */
export function Panel({
  children,
  tone = "default",
  flush = false,
  style,
}: PanelProps) {
  const cls = [styles.panel, styles[tone], flush ? styles.flush : ""]
    .filter(Boolean)
    .join(" ");
  return (
    <div className={cls} style={style}>
      {children}
    </div>
  );
}
