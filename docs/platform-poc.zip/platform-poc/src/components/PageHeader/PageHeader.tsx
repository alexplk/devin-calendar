import type { ReactNode } from "react";
import { Heading } from "../../components/Heading";
import styles from "./PageHeader.module.css";

type PageHeaderProps = {
  breadcrumb?: ReactNode;
  title: string;
  /** status / category chips shown under the title */
  tags?: ReactNode;
  /** primary/secondary actions, right-aligned */
  actions?: ReactNode;
  description?: string;
};

/** Standard page heading block: breadcrumb, title row + actions, tags, blurb. */
export function PageHeader({
  breadcrumb,
  title,
  tags,
  actions,
  description,
}: PageHeaderProps) {
  return (
    <div className={styles.header}>
      {breadcrumb && <div className={styles.breadcrumb}>{breadcrumb}</div>}
      {tags && <div className={styles.tags}>{tags}</div>}
      <div className={styles.titleRow}>
        <Heading level={1}>{title}</Heading>
        {actions && <div className={styles.actions}>{actions}</div>}
      </div>
      {description && <p className={styles.description}>{description}</p>}
    </div>
  );
}
