import styles from "./Placeholder.module.css";

type PlaceholderProps = {
  /** what this stands in for, e.g. "Composition diagram" */
  label: string;
  /** fixed height; defaults to a medium block */
  height?: number | string;
};

/**
 * A shaded box that names what it represents. Used for not-yet-built things:
 * charts, diagrams, tabs we couldn't see in the designs.
 */
export function Placeholder({ label, height = 160 }: PlaceholderProps) {
  return (
    <div
      className={styles.placeholder}
      style={{ height: typeof height === "number" ? `${height}px` : height }}
    >
      <span className={styles.label}>{label}</span>
    </div>
  );
}
