import type { ReactNode } from "react";
import { IconBox } from "../../components/IconBox";
import styles from "./ListRow.module.css";

type ListRowProps = {
  glyph?: string;
  /** small label above the title, e.g. "Sub-agent · Skill" */
  eyebrow?: string;
  title: string;
  meta?: string;
  description?: string;
  tags?: ReactNode;
  action?: ReactNode;
};

/**
 * One row in an asset list (sub-agents, skills, tools, agent inventory).
 * Owns the icon + text + tags + action arrangement.
 */
export function ListRow({
  glyph,
  eyebrow,
  title,
  meta,
  description,
  tags,
  action,
}: ListRowProps) {
  return (
    <div className={styles.row}>
      <IconBox glyph={glyph} size="medium" />
      <div className={styles.body}>
        {eyebrow && <div className={styles.eyebrow}>{eyebrow}</div>}
        <div className={styles.title}>{title}</div>
        {meta && <div className={styles.meta}>{meta}</div>}
        {description && <p className={styles.description}>{description}</p>}
        {tags && <div className={styles.tags}>{tags}</div>}
      </div>
      {action && <div className={styles.action}>{action}</div>}
    </div>
  );
}
