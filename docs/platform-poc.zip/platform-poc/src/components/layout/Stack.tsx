import type { CSSProperties, ElementType, ReactNode } from "react";
import { sizeVar, type SizeStep } from "../tokens";

type StackProps = {
  children: ReactNode;
  /** gap between children, on the primitive size scale */
  gap?: SizeStep;
  align?: CSSProperties["alignItems"];
  as?: ElementType;
  className?: string;
  style?: CSSProperties;
};

/** Vertical flow with a token-driven gap. Pure layout, no visual styling. */
export function Stack({
  children,
  gap = 4,
  align,
  as: Tag = "div",
  className,
  style,
}: StackProps) {
  return (
    <Tag
      className={className}
      style={{
        display: "flex",
        flexDirection: "column",
        gap: sizeVar(gap),
        alignItems: align,
        ...style,
      }}
    >
      {children}
    </Tag>
  );
}
