import type { CSSProperties, ReactNode } from "react";
import { sizeVar, type SizeStep } from "../tokens";

type ColumnsProps = {
  main: ReactNode;
  aside: ReactNode;
  /** width of the aside column */
  asideWidth?: string;
  gap?: SizeStep;
  style?: CSSProperties;
};

/** Two-column main + aside layout (used by detail pages). */
export function Columns({
  main,
  aside,
  asideWidth = "300px",
  gap = 8,
  style,
}: ColumnsProps) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: `minmax(0, 1fr) ${asideWidth}`,
        gap: sizeVar(gap),
        alignItems: "start",
        ...style,
      }}
    >
      <div style={{ minWidth: 0 }}>{main}</div>
      <div>{aside}</div>
    </div>
  );
}
