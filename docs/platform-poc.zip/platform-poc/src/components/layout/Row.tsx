import type { CSSProperties, ElementType, ReactNode } from "react";
import { sizeVar, type SizeStep } from "../tokens";

type RowProps = {
  children: ReactNode;
  gap?: SizeStep;
  align?: CSSProperties["alignItems"];
  justify?: CSSProperties["justifyContent"];
  wrap?: boolean;
  as?: ElementType;
  className?: string;
  style?: CSSProperties;
};

/** Horizontal flow with a token-driven gap. Pure layout. */
export function Row({
  children,
  gap = 4,
  align = "center",
  justify,
  wrap = false,
  as: Tag = "div",
  className,
  style,
}: RowProps) {
  return (
    <Tag
      className={className}
      style={{
        display: "flex",
        flexDirection: "row",
        gap: sizeVar(gap),
        alignItems: align,
        justifyContent: justify,
        flexWrap: wrap ? "wrap" : "nowrap",
        ...style,
      }}
    >
      {children}
    </Tag>
  );
}
