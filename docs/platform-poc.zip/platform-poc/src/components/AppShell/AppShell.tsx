import { Outlet } from "react-router-dom";
import { Masthead } from "../Masthead/Masthead";
import { SideNav } from "../SideNav/SideNav";
import styles from "./AppShell.module.css";

/**
 * Application shell: static masthead across the top, drafted side nav on the
 * left, and the routed page in the scrolling content area. Used as the layout
 * route so every page is rendered inside it.
 */
export function AppShell() {
  return (
    <div className={styles.shell}>
      <Masthead />
      <div className={styles.body}>
        <aside className={styles.sidebar}>
          <SideNav />
        </aside>
        <main className={styles.content}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
