import { IconBox } from "../../components/IconBox";
import styles from "./Masthead.module.css";

/**
 * Static top chrome shown above every page: brand, global search, account.
 * Intentionally static — it doesn't change between pages.
 */
export function Masthead() {
  return (
    <header className={styles.masthead}>
      <div className={styles.brand}>
        <span className={styles.logo}>ORG</span>
        <span className={styles.product}>One AI Platform</span>
      </div>

      <label className={styles.search}>
        <span className={styles.searchIcon} aria-hidden="true" />
        <input
          className={styles.searchInput}
          placeholder="Search agents, skills, data…"
          aria-label="Global search"
        />
      </label>

      <div className={styles.actions}>
        <IconBox glyph="?" size="small" shape="circle" />
        <IconBox glyph="!" size="small" shape="circle" />
        <IconBox glyph="AP" size="small" shape="circle" />
      </div>
    </header>
  );
}
