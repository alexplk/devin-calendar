/* Typed helpers for referencing design tokens from TS (layout props etc).
 * These return CSS var() references — never raw values — so components stay
 * bound to the design system in global-design.css.
 */

// The primitive size scale keys available as --company-primitive-size-*.
export type SizeStep =
  | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14;

export const sizeVar = (step: SizeStep): string =>
  `var(--company-primitive-size-${step})`;
