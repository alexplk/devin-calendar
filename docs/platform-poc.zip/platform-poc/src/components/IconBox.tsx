import styles from "./IconBox.module.css";

type IconBoxProps = {
  /** one or two letters to stand in for a real icon/avatar */
  glyph?: string;
  size?: "small" | "medium" | "large";
  shape?: "square" | "circle";
};

/** Placeholder for an icon or avatar (no icon set wired up yet). */
export function IconBox({
  glyph = "",
  size = "medium",
  shape = "square",
}: IconBoxProps) {
  return (
    <span className={[styles.box, styles[size], styles[shape]].join(" ")}>
      {glyph}
    </span>
  );
}
