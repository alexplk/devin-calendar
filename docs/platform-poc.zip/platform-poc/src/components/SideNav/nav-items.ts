/* Navigation model. Kept as data so the nav reads declaratively and the set
 * of destinations is editable in one place. */

export type NavItem = {
  label: string;
  to: string;
  glyph: string;
  badge?: number;
};

export type NavGroup = {
  heading?: string;
  items: NavItem[];
};

export const navGroups: NavGroup[] = [
  {
    items: [
      { label: "Home", to: "/", glyph: "H" },
      { label: "Recent prompts", to: "/recent", glyph: "R" },
      { label: "My agents", to: "/my-agents", glyph: "A", badge: 3 },
      { label: "My data", to: "/my-data", glyph: "D" },
    ],
  },
  {
    heading: "Marketplace",
    items: [
      { label: "Featured", to: "/featured", glyph: "F" },
      { label: "Agents", to: "/agents", glyph: "Ag" },
      { label: "Skills", to: "/skills", glyph: "Sk" },
      { label: "Tools", to: "/tools", glyph: "To" },
      { label: "Datasets", to: "/datasets", glyph: "Ds" },
      { label: "Data products", to: "/data-products", glyph: "Dp" },
      { label: "Models & workloads", to: "/models", glyph: "Mw" },
      { label: "Policies", to: "/policies", glyph: "Po" },
    ],
  },
  {
    items: [
      { label: "Updates", to: "/updates", glyph: "Up" },
      { label: "Favourites", to: "/favourites", glyph: "★" },
      { label: "Observability", to: "/observability", glyph: "Ob" },
      { label: "System", to: "/system", glyph: "Sy" },
      { label: "Users", to: "/users", glyph: "Us" },
    ],
  },
];
