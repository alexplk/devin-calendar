import { NavLink } from "react-router-dom";
import { IconBox } from "../../components/IconBox";
import { navGroups } from "./nav-items";
import styles from "./SideNav.module.css";

/** Drafted left navigation. Data-driven from nav-items.ts. */
export function SideNav() {
  return (
    <nav className={styles.nav} aria-label="Primary">
      {navGroups.map((group, i) => (
        <div key={group.heading ?? i} className={styles.group}>
          {group.heading && (
            <div className={styles.heading}>{group.heading}</div>
          )}
          {group.items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === "/"}
              className={({ isActive }) =>
                [styles.item, isActive ? styles.active : ""].join(" ")
              }
            >
              <IconBox glyph={item.glyph} size="small" />
              <span className={styles.label}>{item.label}</span>
              {item.badge != null && (
                <span className={styles.badge}>{item.badge}</span>
              )}
            </NavLink>
          ))}
        </div>
      ))}
    </nav>
  );
}
