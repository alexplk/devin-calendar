import type { ReactNode } from "react";
import styles from "./PropertyGrid.module.css";

export type Property = {
  label: ReactNode;
  value: ReactNode;
};

type PropertyGridProps = {
  items: Property[];
  /**
   * inline  → label on the left, value on the right (definition list)
   * stacked → label above value (header/content), laid out in columns
   */
  layout?: "inline" | "stacked";
  /** stacked only: number of columns; defaults to one per item (single row) */
  columns?: number;
};

/** Renders key/value pairs in the two shapes seen in the designs. */
export function PropertyGrid({
  items,
  layout = "inline",
  columns,
}: PropertyGridProps) {
  if (layout === "stacked") {
    return (
      <dl
        className={styles.stacked}
        style={{
          gridTemplateColumns: `repeat(${columns ?? items.length}, minmax(0, 1fr))`,
        }}
      >
        {items.map((item, i) => (
          <div key={i} className={styles.stackedCell}>
            <dt className={styles.stackedLabel}>{item.label}</dt>
            <dd className={styles.stackedValue}>{item.value}</dd>
          </div>
        ))}
      </dl>
    );
  }

  return (
    <dl className={styles.inline}>
      {items.map((item, i) => (
        <div key={i} className={styles.inlineRow}>
          <dt className={styles.inlineLabel}>{item.label}</dt>
          <dd className={styles.inlineValue}>{item.value}</dd>
        </div>
      ))}
    </dl>
  );
}
