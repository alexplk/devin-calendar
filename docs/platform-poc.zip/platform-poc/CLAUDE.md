# platform — UI sandbox

Vite + React + TS sandbox for experimenting with UI organization ideas. No Tailwind or utility-first frameworks; styling is plain CSS consuming design tokens.

**Before building any UI here, read and follow the UI architecture doc:** `./ARCHITECTURE.md`

Key points (full detail in the spec):
- Business code describes intent, not UI implementation. Pages read like a list of business capabilities, not layout/CSS plumbing.
- Layers: components (domain-blind building blocks — single elements *and* compositions, incl. CSS/a11y) → capabilities (business/domain concepts) → pages (orchestration only). Dependencies point downward only; nothing reaches sideways or up. The only boundary is "does it know the domain?".
- Component vs. global class: if styling requires remembering DOM structure, make a component; if it applies directly to a semantic element, a global class is fine.
- Tokens live in `src/global-design.css` (`--company-primitive-*`, `--company-semantic-*`), imported at the root. Consume tokens; never hardcode raw values.
